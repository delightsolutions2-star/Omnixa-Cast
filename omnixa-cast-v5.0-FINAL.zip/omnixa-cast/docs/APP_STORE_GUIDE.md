# OMNIXA Cast — App Store Submission Guide

---

## 🟦 Samsung Tizen (Samsung Smart TV)

### Requirements
- Samsung Developer Account: https://developer.samsung.com
- Tizen Studio IDE (free): https://developer.tizen.org/tizen-studio
- Your server must be HTTPS for production (self-signed cert causes SEC_ERROR_UNKNOWN_ISSUER on Tizen)

### Steps
1. **Register** at developer.samsung.com → Create Partner Account
2. **Install Tizen Studio** → Add TV Extensions via Package Manager
3. **Create a Web App project** (type: Web Application)
4. Copy `client/tv/index.html` content into your Tizen project's `index.html`
5. Update `config.xml`:
   ```xml
   <tizen:application id="XXXXXXXX.OmnixaCast" package="XXXXXXXX" required_version="5.0"/>
   <content src="index.html"/>
   <access origin="*" subdomains="true"/>
   ```
6. **Test** on Samsung TV emulator or real device via Remote Device Manager
7. **Build** → Right-click project → Build Package → generates `.wgt`
8. **Submit** at https://seller.samsungapps.com → TV → Upload `.wgt`

### Key Limitations
- Tizen browser = Chrome 76 (Chromium based) — no ES2020+ syntax
- Use compat Firebase SDK (already done in `client/tv/index.html`)
- WebRTC fully supported on Tizen 5+
- mDNS discovery: works via broadcast on LAN, not via Bonjour

---

## 🟥 LG webOS (LG Smart TV)

### Requirements
- LG Developer Account: https://webostv.developer.lge.com
- webOS SDK (CLI): `npm install -g @webos-tools/cli`
- ARES CLI for packaging

### Steps
1. **Register** at webostv.developer.lge.com
2. **Install webOS TV CLI**:
   ```bash
   npm install -g @webos-tools/cli
   ares-setup-device  # Configure your LG TV IP
   ```
3. Create project structure:
   ```
   omnixa-webos/
     appinfo.json
     index.html       ← copy from client/tv/index.html
     icon.png         ← 80x80 PNG
     largeIcon.png    ← 130x130 PNG
   ```
4. `appinfo.json`:
   ```json
   {
     "id": "com.omnixa.cast",
     "version": "1.0.0",
     "vendor": "OMNIXA",
     "type": "web",
     "main": "index.html",
     "title": "OMNIXA Cast",
     "icon": "icon.png",
     "largeIcon": "largeIcon.png",
     "bgColor": "#050709"
   }
   ```
5. **Package**: `ares-package omnixa-webos/`
6. **Install on TV**: `ares-install --device tv com.omnixa.cast_1.0.0_all.ipk`
7. **Test** remotely: `ares-launch --device tv com.omnixa.cast`
8. **Submit** at https://seller.lgappstv.com

### Key Limitations
- webOS 6 = Chrome 79 — use compat SDK (already done)
- WebRTC fully supported on webOS 6+
- File size limit: 100MB for packaged app

---

## 🟩 Android TV / Google Play

### Requirements
- Google Play Developer Account ($25 one-time): https://play.google.com/console
- Android Studio
- The React Native app in `android-app/` is ready to build

### Steps
1. **Add** `google-services.json` to `android-app/android/app/`
   (Download from Firebase Console → Project Settings → Android)

2. **Update** `android/app/build.gradle`:
   ```gradle
   defaultConfig {
     applicationId "com.omnixa.cast"
     minSdkVersion 21
     targetSdkVersion 34
     versionCode 1
     versionName "1.0.0"
   }
   ```

3. **Add TV support** to `AndroidManifest.xml`:
   ```xml
   <uses-feature android:name="android.software.leanback" android:required="false"/>
   <uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
   <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>
   ```

4. **Build release APK**:
   ```bash
   cd android-app/android
   ./gradlew bundleRelease
   # Output: android/app/build/outputs/bundle/release/app-release.aab
   ```

5. **Sign** with your keystore:
   ```bash
   keytool -genkey -v -keystore omnixa-cast.keystore -alias omnixa -keyalg RSA -keysize 2048 -validity 10000
   ```

6. **Submit** at https://play.google.com/console → Create App → Upload `.aab`
   - Category: Video Players & Editors
   - Target device: Android TV

### Key Notes
- WebRTC (`react-native-webrtc`) fully supports Android TV
- Use Leanback launcher for TV home screen visibility
- D-pad navigation is handled by React Native's built-in focus system

---

## 🔒 Production Deployment Checklist

Before submitting to any store:

- [ ] Server deployed with HTTPS (nginx + Let's Encrypt or Cloudflare)
- [ ] WebSocket uses WSS (`wss://`)
- [ ] TURN server configured for cloud casting
- [ ] Firebase App Check enabled
- [ ] CASTING_MODE set appropriately in `.env`
- [ ] Firebase Security Rules configured (Firestore, Storage)
- [ ] Error monitoring set up (Sentry, Firebase Crashlytics)
- [ ] Privacy Policy URL ready (required by all stores)

