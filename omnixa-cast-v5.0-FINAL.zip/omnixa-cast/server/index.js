/**
 * OMNIXA CAST — Signaling Server v1.1
 * Fixes: device ID relay, QR WS-push, stale peer cleanup, heartbeat
 */
require('dotenv').config();
const express   = require('express');
const http      = require('http');
const WebSocket = require('ws');
const cors      = require('cors');
const path      = require('path');
const QRCode    = require('qrcode');
const os        = require('os');
const crypto    = require('crypto');
const registry  = require('./rooms');
const discovery = require('./discovery');

const PORT   = process.env.PORT || 3000;
const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server, clientTracking: true });

// ─── Helpers ─────────────────────────────────────────────────────────────────
function getLanIP() {
  for (const iface of Object.values(os.networkInterfaces())) {
    for (const addr of iface) {
      if (addr.family === 'IPv4' && !addr.internal) return addr.address;
    }
  }
  return 'localhost';
}

function send(ws, data) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}

function findSocket(deviceId) {
  return [...wss.clients].find(ws => ws.deviceId === deviceId) || null;
}

function broadcastDeviceList() {
  const list = registry.getAllDevices().map(d => ({
    id: d.id, name: d.name, type: d.type, role: d.role, authenticated: d.authenticated
  }));
  wss.clients.forEach(ws => send(ws, { type: 'device_list', devices: list }));
}

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.use('/shared', express.static(path.join(__dirname, '../public/shared')));

// ─── Static pages ─────────────────────────────────────────────────────────────
app.get('/sender',   (req, res) => res.sendFile(path.join(__dirname, '../client/sender/index.html')));
app.get('/receiver', (req, res) => res.sendFile(path.join(__dirname, '../client/receiver/index.html')));
app.get('/tv',       (req, res) => res.sendFile(path.join(__dirname, '../client/tv/index.html')));
app.get('/tv-auth',  (req, res) => res.sendFile(path.join(__dirname, '../client/tv/auth.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, '../client/dashboard/index.html')));

// ─── API ──────────────────────────────────────────────────────────────────────
app.get('/api/qr/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const LAN = getLanIP();
    const authUrl = `http://${LAN}:${PORT}/tv-auth?token=${token}`;
    const qr = await QRCode.toDataURL(authUrl, {
      width: 280, margin: 2,
      color: { dark: '#ffffff', light: '#00000000' }
    });
    res.json({ qr, url: authUrl, token });
  } catch (e) { res.status(500).json({ error: 'QR generation failed' }); }
});

// Poll endpoint kept as fallback (WS push is primary)
app.get('/api/qr/poll/:token', (req, res) => {
  const result = registry.pollQRToken(req.params.token);
  res.json(result || { status: 'not_found' });
});

app.post('/api/qr/resolve', (req, res) => {
  const { token, userId } = req.body;
  if (!token || !userId) return res.status(400).json({ error: 'Missing fields' });
  const result = registry.resolveQRToken(token, userId);
  if (!result) return res.status(404).json({ error: 'Token not found or expired' });

  // Push auth complete to TV via WebSocket (primary notification)
  const tvSocket = findSocket(result.deviceId);
  if (tvSocket) send(tvSocket, { type: 'qr_auth_complete', userId });

  res.json({ success: true });
});

app.get('/api/devices', (req, res) => {
  res.json(registry.getAllDevices().map(d => ({
    id: d.id, name: d.name, type: d.type, role: d.role, authenticated: d.authenticated
  })));
});

// ─── WebSocket Signaling ──────────────────────────────────────────────────────
wss.on('connection', (ws) => {
  const socketId = crypto.randomUUID();
  ws.deviceId = socketId;
  ws.isAlive = true;

  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    const { type, payload = {} } = msg;

    switch (type) {

      case 'register': {
        const device = registry.registerDevice(socketId, {
          name: payload.name || 'Unknown',
          type: payload.deviceType || 'desktop',
          userId: payload.userId || null,
          authenticated: !!payload.userId,
        });
        // BUG-01 FIX: send deviceId back so client can filter itself from device list
        send(ws, { type: 'registered', device, yourId: socketId });
        broadcastDeviceList();

        // TV: issue QR token if not already authenticated
        const isTV = ['tv_tizen','tv_webos','tv_android'].includes(payload.deviceType);
        if (isTV && !payload.userId) {
          const token = registry.createQRToken(socketId);
          send(ws, { type: 'qr_token', token });
        }
        break;
      }

      case 'auth_update': {
        const device = registry.updateDeviceAuth(socketId, payload.userId);
        send(ws, { type: 'auth_confirmed', device, yourId: socketId });
        broadcastDeviceList();
        break;
      }

      case 'create_room': {
        const device = registry.getDevice(socketId);
        if (!device?.authenticated) { send(ws, { type: 'error', message: 'Not authenticated' }); break; }
        const room = registry.createRoom(socketId);
        if (!room) { send(ws, { type: 'error', message: 'Room creation failed' }); break; }
        send(ws, { type: 'room_created', roomId: room.id });
        broadcastDeviceList();
        console.log(`🏠 Room ${room.id} created by ${device.name}`);
        break;
      }

      case 'join_room': {
        const device = registry.getDevice(socketId);
        if (!device?.authenticated) { send(ws, { type: 'error', message: 'Not authenticated' }); break; }
        const room = registry.joinRoom(socketId, payload.roomId);
        if (!room) { send(ws, { type: 'error', message: 'Room not found or inactive' }); break; }
        send(ws, { type: 'room_joined', roomId: room.id });

        // Notify sender → triggers createOffer (BUG-02 primary fix is client-side)
        const hostSock = findSocket(room.hostId);
        if (hostSock) {
          send(hostSock, {
            type: 'receiver_joined',
            receiverId: socketId,
            receiverName: device.name,
            receiverType: device.type
          });
        }
        broadcastDeviceList();
        console.log(`👥 ${device.name} joined room ${room.id}`);
        break;
      }

      // ── WebRTC relay ──────────────────────────────────────────────────────
      case 'offer': {
        const t = findSocket(payload.targetId);
        if (t) send(t, { type: 'offer', sdp: payload.sdp, senderId: socketId });
        break;
      }
      case 'answer': {
        const t = findSocket(payload.targetId);
        if (t) send(t, { type: 'answer', sdp: payload.sdp, receiverId: socketId });
        break;
      }
      case 'ice_candidate': {
        const t = findSocket(payload.targetId);
        if (t) send(t, { type: 'ice_candidate', candidate: payload.candidate, fromId: socketId });
        break;
      }

      // ── Room leave ────────────────────────────────────────────────────────
      case 'leave_room': {
        const device = registry.getDevice(socketId);
        if (!device?.roomId) break;
        const room = registry.getRoom(device.roomId);
        if (room) {
          if (room.hostId === socketId) {
            // Notify all receivers cast ended
            Array.from(room.receivers).forEach(rid => {
              const s = findSocket(rid);
              if (s) send(s, { type: 'cast_ended', reason: 'host_left' });
            });
          } else {
            const hostSock = findSocket(room.hostId);
            if (hostSock) send(hostSock, { type: 'receiver_left', receiverId: socketId });
          }
        }
        registry.leaveRoom(socketId, device.roomId);
        broadcastDeviceList();
        break;
      }
    }
  });

  ws.on('close', () => {
    const device = registry.getDevice(socketId);
    if (device?.roomId) {
      const room = registry.getRoom(device.roomId);
      if (room && room.hostId === socketId) {
        Array.from(room.receivers).forEach(rid => {
          const s = findSocket(rid);
          if (s) send(s, { type: 'cast_ended', reason: 'host_disconnected' });
        });
      } else if (room) {
        const hostSock = findSocket(room.hostId);
        if (hostSock) send(hostSock, { type: 'receiver_left', receiverId: socketId });
      }
    }
    registry.unregisterDevice(socketId);
    broadcastDeviceList();
    console.log(`🔌 Disconnected: ${socketId.slice(0,8)}`);
  });

  ws.on('error', err => console.error(`❌ WS error ${socketId.slice(0,8)}:`, err.message));
});

// ─── Heartbeat — detect and clean up dead connections (RISK-04 fix) ──────────
const heartbeat = setInterval(() => {
  wss.clients.forEach(ws => {
    if (!ws.isAlive) {
      const device = registry.getDevice(ws.deviceId);
      if (device) registry.unregisterDevice(ws.deviceId);
      return ws.terminate();
    }
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

wss.on('close', () => clearInterval(heartbeat));

// ─── Start ────────────────────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  const LAN = getLanIP();
  console.log(`\n╔══════════════════════════════════════════════════╗`);
  console.log(`║          OMNIXA CAST SERVER  v1.1               ║`);
  console.log(`╠══════════════════════════════════════════════════╣`);
  console.log(`║  Local:    http://localhost:${PORT}               ║`);
  console.log(`║  Network:  http://${LAN}:${PORT}             ║`);
  console.log(`║  Sender:   http://${LAN}:${PORT}/sender      ║`);
  console.log(`║  Receiver: http://${LAN}:${PORT}/receiver    ║`);
  console.log(`║  TV:       http://${LAN}:${PORT}/tv          ║`);
  console.log(`╚══════════════════════════════════════════════════╝\n`);
  discovery.startDiscovery(PORT);
});

process.on('SIGINT', () => { discovery.stopDiscovery(); process.exit(0); });

// ── Room Join QR (for non-TV devices) ────────────────────────────────────────
app.get('/api/room-qr/:roomId', async (req, res) => {
  try {
    const { roomId } = req.params;
    const LAN = getLanIP();
    const joinUrl = `http://${LAN}:${PORT}/receiver?room=${roomId}`;
    const qr = await QRCode.toDataURL(joinUrl, {
      width: 220, margin: 2,
      color: { dark: '#00d4ff', light: '#00000000' }
    });
    res.json({ qr, url: joinUrl, roomId });
  } catch (e) { res.status(500).json({ error: 'QR generation failed' }); }
});



// ── Push Notification Token Storage (Phase 6) ─────────────────────────────────
const pushTokens = new Map(); // userId → [fcmToken]

app.post('/api/push-token', (req, res) => {
  const { token, userId } = req.body;
  if (!token || !userId) return res.status(400).json({ error: 'Missing fields' });
  if (!pushTokens.has(userId)) pushTokens.set(userId, new Set());
  pushTokens.get(userId).add(token);
  res.json({ success: true });
});

app.get('/api/push-tokens/:userId', (req, res) => {
  const tokens = Array.from(pushTokens.get(req.params.userId) || []);
  res.json({ tokens });
});

// Serve push SW config (injects Firebase config into SW context)
app.get('/sw-config', (req, res) => {
  res.type('application/javascript');
  res.send('// Firebase config injected by server — configure in public/shared/firebase.js');
});

// ── Scheduled Casts API (Phase 5) ─────────────────────────────────────────────

// Create a scheduled cast
app.post('/api/scheduled', (req, res) => {
  const { hostUserId, hostName, title, scheduledAt, passwordHash, durationMinutes } = req.body;
  if (!hostUserId || !scheduledAt) return res.status(400).json({ error: 'Missing required fields' });
  const cast = scheduler.createScheduledCast({ hostUserId, hostName, title, scheduledAt, passwordHash, durationMinutes });
  res.json(scheduler.serializeCast(cast));
});

// List upcoming casts (optionally filtered by userId)
app.get('/api/scheduled', (req, res) => {
  const casts = scheduler.listUpcomingCasts(req.query.userId || null);
  res.json(casts.map(scheduler.serializeCast));
});

// Get a specific scheduled cast
app.get('/api/scheduled/:castId', (req, res) => {
  const cast = scheduler.getScheduledCast(req.params.castId);
  if (!cast) return res.status(404).json({ error: 'Cast not found' });
  res.json(scheduler.serializeCast(cast));
});

// Cancel a scheduled cast
app.delete('/api/scheduled/:castId', (req, res) => {
  const result = scheduler.cancelScheduledCast(req.params.castId, req.body.userId);
  if (!result) return res.status(403).json({ error: 'Not found or not authorized' });
  res.json({ success: true, id: req.params.castId });
});

// ── ICE / TURN Config API (Phase 4) ──────────────────────────────────────────
const iceConfig   = require('./ice-config');
const scheduler   = require('./scheduler');
const chat        = require('./chat');
const handoff    = require('./handoff');

app.get('/api/ice-config', (req, res) => {
  res.json(iceConfig.getICEConfigForClient());
});

app.get('/api/casting-mode', (req, res) => {
  res.json({ mode: iceConfig.CASTING_MODE });
});
