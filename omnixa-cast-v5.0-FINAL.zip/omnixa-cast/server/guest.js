
// ── Guest Mode — Server additions to rooms.js ─────────────────────────────
// Add to rooms.js exports

const guestRequests = new Map(); // roomId → [{ guestId, guestName, status }]

function requestGuestJoin(guestSocketId, roomId, guestName) {
  if (!guestRequests.has(roomId)) guestRequests.set(roomId, []);
  const list = guestRequests.get(roomId);
  // Check not already pending
  if (list.find(r => r.guestId === guestSocketId)) return null;
  const req = { guestId: guestSocketId, guestName: guestName || 'Guest', status: 'pending', createdAt: Date.now() };
  list.push(req);
  return req;
}

function approveGuest(roomId, guestSocketId) {
  const list = guestRequests.get(roomId) || [];
  const req = list.find(r => r.guestId === guestSocketId);
  if (req) req.status = 'approved';
  return req;
}

function denyGuest(roomId, guestSocketId) {
  const list = guestRequests.get(roomId) || [];
  const idx = list.findIndex(r => r.guestId === guestSocketId);
  if (idx > -1) list.splice(idx, 1);
}

function getPendingGuests(roomId) {
  return (guestRequests.get(roomId) || []).filter(r => r.status === 'pending');
}
