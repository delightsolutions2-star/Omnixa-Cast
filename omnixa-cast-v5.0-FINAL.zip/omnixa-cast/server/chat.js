/**
 * OMNIXA CAST — Live Chat Manager (Phase 6)
 * Stores messages per room, handles rate limiting, profanity guard stub
 */

const chatHistory = new Map(); // roomId → [Message]
const MAX_MESSAGES_PER_ROOM = 500;
const RATE_LIMIT_MS = 1000; // 1 message per second per user
const lastMessageTime = new Map(); // userId → timestamp

function sendMessage(roomId, { userId, userName, text, type = 'chat' }) {
  // Rate limit
  const last = lastMessageTime.get(userId) || 0;
  if (Date.now() - last < RATE_LIMIT_MS) return null;
  lastMessageTime.set(userId, Date.now());

  // Sanitize
  const sanitized = text.trim().slice(0, 500);
  if (!sanitized) return null;

  const msg = {
    id:        `${Date.now()}-${Math.random().toString(36).slice(2,6)}`,
    roomId,
    userId,
    userName:  userName || 'Anonymous',
    text:      sanitized,
    type,      // 'chat' | 'question' | 'system'
    ts:        Date.now(),
    answered:  false,
    reactions: {},
  };

  if (!chatHistory.has(roomId)) chatHistory.set(roomId, []);
  const history = chatHistory.get(roomId);
  history.push(msg);
  if (history.length > MAX_MESSAGES_PER_ROOM) history.shift();

  return msg;
}

function getHistory(roomId, limit = 50) {
  return (chatHistory.get(roomId) || []).slice(-limit);
}

function markAnswered(roomId, msgId) {
  const history = chatHistory.get(roomId) || [];
  const msg = history.find(m => m.id === msgId);
  if (msg) msg.answered = true;
  return msg;
}

function addReaction(roomId, msgId, emoji, userId) {
  const history = chatHistory.get(roomId) || [];
  const msg     = history.find(m => m.id === msgId);
  if (!msg) return null;
  if (!msg.reactions[emoji]) msg.reactions[emoji] = new Set();
  msg.reactions[emoji].add(userId);
  return { emoji, count: msg.reactions[emoji].size };
}

function clearRoom(roomId) {
  chatHistory.delete(roomId);
}

module.exports = { sendMessage, getHistory, markAnswered, addReaction, clearRoom };
