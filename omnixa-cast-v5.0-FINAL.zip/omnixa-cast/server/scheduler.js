/**
 * OMNIXA CAST — Scheduled Cast Manager (Phase 5)
 * Stores upcoming cast sessions in memory (+ Firebase Firestore if configured)
 * Each scheduled cast has a stable join link generated before the session starts
 */

const { v4: uuidv4 } = require('uuid');

const scheduledCasts = new Map(); // castId → ScheduledCast

function createScheduledCast({ hostUserId, hostName, title, scheduledAt, passwordHash = null, durationMinutes = 60 }) {
  const castId  = uuidv4().substring(0, 8).toUpperCase();
  const joinUrl = `/receiver?room=${castId}`;

  const cast = {
    id:              castId,
    hostUserId,
    hostName,
    title:           title || 'Untitled Cast',
    scheduledAt:     new Date(scheduledAt).getTime(),
    expiresAt:       new Date(scheduledAt).getTime() + durationMinutes * 60 * 1000,
    passwordHash,
    passwordProtected: !!passwordHash,
    joinUrl,
    status:          'scheduled', // scheduled | live | ended | cancelled
    createdAt:       Date.now(),
  };

  scheduledCasts.set(castId, cast);
  scheduleAutoExpiry(castId, cast.expiresAt);
  console.log(`📅 [Scheduler] Scheduled: "${cast.title}" at ${new Date(cast.scheduledAt).toISOString()} (ID: ${castId})`);
  return cast;
}

function getScheduledCast(castId) {
  return scheduledCasts.get(castId) || null;
}

function listUpcomingCasts(userId = null) {
  const now   = Date.now();
  const casts = Array.from(scheduledCasts.values())
    .filter(c => c.expiresAt > now && c.status !== 'cancelled')
    .filter(c => !userId || c.hostUserId === userId)
    .sort((a, b) => a.scheduledAt - b.scheduledAt);
  return casts;
}

function cancelScheduledCast(castId, userId) {
  const cast = scheduledCasts.get(castId);
  if (!cast) return null;
  if (cast.hostUserId !== userId) return null; // only host can cancel
  cast.status = 'cancelled';
  return cast;
}

function markCastLive(castId) {
  const cast = scheduledCasts.get(castId);
  if (cast) cast.status = 'live';
  return cast;
}

function markCastEnded(castId) {
  const cast = scheduledCasts.get(castId);
  if (cast) { cast.status = 'ended'; cast.endedAt = Date.now(); }
  return cast;
}

function scheduleAutoExpiry(castId, expiresAt) {
  const ms = expiresAt - Date.now();
  if (ms > 0) {
    setTimeout(() => {
      const c = scheduledCasts.get(castId);
      if (c && c.status === 'scheduled') { c.status = 'ended'; }
    }, ms);
  }
}

// Serialize for API (omit sensitive data)
function serializeCast(cast) {
  return {
    id:               cast.id,
    hostName:         cast.hostName,
    title:            cast.title,
    scheduledAt:      cast.scheduledAt,
    expiresAt:        cast.expiresAt,
    status:           cast.status,
    passwordProtected:cast.passwordProtected,
    joinUrl:          cast.joinUrl,
    isLive:           cast.status === 'live',
    minutesUntilStart:Math.max(0, Math.round((cast.scheduledAt - Date.now()) / 60000)),
  };
}

module.exports = { createScheduledCast, getScheduledCast, listUpcomingCasts, cancelScheduledCast, markCastLive, markCastEnded, serializeCast };
