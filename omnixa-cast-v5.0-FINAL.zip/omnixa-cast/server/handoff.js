/**
 * OMNIXA CAST — Presenter Handoff (Phase 4)
 * Manages transfer of the "active sender" role between authenticated users
 *
 * Flow:
 *   Current host → sends handoff_request to target device
 *   Target device → accepts or declines
 *   On accept → role swapped, all receivers re-routed to new sender
 */

const pendingHandoffs = new Map(); // token → { fromId, toId, roomId, expiry }
const crypto = require('crypto');

function createHandoffRequest(fromId, toId, roomId) {
  const token = crypto.randomBytes(4).toString('hex').toUpperCase();
  pendingHandoffs.set(token, {
    fromId, toId, roomId,
    status: 'pending',
    createdAt: Date.now(),
    expiry: Date.now() + 60_000, // 60 second window
  });
  return token;
}

function acceptHandoff(token) {
  const h = pendingHandoffs.get(token);
  if (!h || Date.now() > h.expiry) return null;
  h.status = 'accepted';
  pendingHandoffs.delete(token);
  return h;
}

function declineHandoff(token) {
  const h = pendingHandoffs.get(token);
  pendingHandoffs.delete(token);
  return h;
}

// Clean up expired requests every 30s
setInterval(() => {
  const now = Date.now();
  for (const [token, h] of pendingHandoffs.entries()) {
    if (now > h.expiry) pendingHandoffs.delete(token);
  }
}, 30_000);

module.exports = { createHandoffRequest, acceptHandoff, declineHandoff };
