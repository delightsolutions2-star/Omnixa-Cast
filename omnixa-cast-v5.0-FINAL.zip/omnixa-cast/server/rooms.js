/**
 * OMNIXA CAST — Room & Device Registry
 */
const { v4: uuidv4 } = require('uuid');

const rooms   = new Map();
const devices = new Map();
const qrTokens = new Map();

const DEVICE_TYPES = { DESKTOP:'desktop', MOBILE:'mobile', TV_TIZEN:'tv_tizen', TV_WEBOS:'tv_webos', TV_ANDROID:'tv_android' };
const ROLES = { SENDER:'sender', RECEIVER:'receiver', IDLE:'idle' };

function registerDevice(socketId, info) {
  const device = { id:socketId, name:info.name||'Unknown Device', type:info.type||DEVICE_TYPES.DESKTOP, role:ROLES.IDLE, roomId:null, userId:info.userId||null, authenticated:info.authenticated||false, connectedAt:Date.now() };
  devices.set(socketId, device);
  return device;
}

function unregisterDevice(socketId) {
  const device = devices.get(socketId);
  if (device && device.roomId) leaveRoom(socketId, device.roomId);
  devices.delete(socketId);
  return device;
}

function getDevice(socketId) { return devices.get(socketId); }
function getAllDevices() { return Array.from(devices.values()); }

function updateDeviceAuth(socketId, userId) {
  const device = devices.get(socketId);
  if (device) { device.authenticated = true; device.userId = userId; }
  return device;
}

function createRoom(hostSocketId, passwordHash=null) {
  const device = devices.get(hostSocketId);
  if (!device) return null;
  const roomId = uuidv4().substring(0,8).toUpperCase();
  const room = { id:roomId, hostId:hostSocketId, hostName:device.name, receivers:new Set(), createdAt:Date.now(), active:true, audioEnabled:false, passwordHash, passwordProtected:!!passwordHash };
  rooms.set(roomId, room);
  device.roomId = roomId;
  device.role = ROLES.SENDER;
  return room;
}

function verifyRoomPassword(roomId, hash) {
  const room = rooms.get(roomId);
  if (!room) return false;
  if (!room.passwordProtected) return true; // no password needed
  return room.passwordHash === hash;        // compare pre-hashed value
}

function joinRoom(socketId, roomId) {
  const room = rooms.get(roomId);
  const device = devices.get(socketId);
  if (!room || !device || !room.active) return null;
  room.receivers.add(socketId);
  device.roomId = roomId;
  device.role = ROLES.RECEIVER;
  return room;
}

function leaveRoom(socketId, roomId) {
  const room = rooms.get(roomId);
  const device = devices.get(socketId);
  if (!room) return;
  if (room.hostId === socketId) {
    room.active = false;
    room.receivers.forEach(rid => { const r = devices.get(rid); if(r){r.roomId=null;r.role=ROLES.IDLE;} });
    rooms.delete(roomId);
  } else { room.receivers.delete(socketId); }
  if (device) { device.roomId=null; device.role=ROLES.IDLE; }
}

function getRoom(roomId) { return rooms.get(roomId); }
function getRoomReceivers(roomId) { const r=rooms.get(roomId); return r?Array.from(r.receivers):[]; }

function createQRToken(deviceId) {
  const token = uuidv4().substring(0,6).toUpperCase();
  qrTokens.set(token, { status:'pending', userId:null, deviceId, createdAt:Date.now(), expiresAt:Date.now()+5*60*1000 });
  return token;
}

function resolveQRToken(token, userId) {
  const e = qrTokens.get(token);
  if (!e || Date.now()>e.expiresAt) { qrTokens.delete(token); return null; }
  e.status='authenticated'; e.userId=userId;
  return e;
}

function pollQRToken(token) {
  const e = qrTokens.get(token);
  if (!e) return null;
  if (Date.now()>e.expiresAt) { qrTokens.delete(token); return {status:'expired'}; }
  return e;
}

setInterval(()=>{ const now=Date.now(); for(const [t,e] of qrTokens.entries()) if(now>e.expiresAt) qrTokens.delete(t); }, 2*60*1000);

function setRoomAudio(roomId, enabled) {
  const room = rooms.get(roomId);
  if (room) room.audioEnabled = !!enabled;
  return room;
}

module.exports = { DEVICE_TYPES, ROLES, registerDevice, unregisterDevice, getDevice, getAllDevices, updateDeviceAuth, createRoom, joinRoom, leaveRoom, getRoom, getRoomReceivers, createQRToken, resolveQRToken, pollQRToken };
