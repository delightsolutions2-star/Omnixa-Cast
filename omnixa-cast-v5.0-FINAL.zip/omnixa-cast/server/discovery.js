/**
 * OMNIXA CAST — mDNS Auto-Discovery
 * Broadcasts service on local network so all devices find the server automatically
 */
const { Bonjour } = require('bonjour-service');

let bonjour = null;
let service = null;

function startDiscovery(port) {
  try {
    bonjour = new Bonjour();
    service = bonjour.publish({
      name: 'OMNIXA Cast Server',
      type: 'omnixa-cast',
      port: port,
      txt: { version: '1.0.0', product: 'OMNIXA Cast' }
    });

    service.on('up', () => {
      console.log(`📡 [mDNS] Service broadcast: omnixa-cast.local:${port}`);
    });

    // Also publish as HTTP service so browsers/TVs can discover it
    bonjour.publish({
      name: 'OMNIXA Cast Web',
      type: 'http',
      port: port,
      txt: { path: '/', product: 'OMNIXA Cast' }
    });

    console.log(`📡 [mDNS] Broadcasting on local network — devices will auto-discover`);
  } catch (err) {
    console.warn(`⚠️  [mDNS] Could not start discovery: ${err.message}`);
    console.warn(`⚠️  [mDNS] Devices will need to connect manually via IP`);
  }
}

function stopDiscovery() {
  if (bonjour) {
    bonjour.unpublishAll();
    bonjour.destroy();
    console.log('📡 [mDNS] Service unpublished');
  }
}

module.exports = { startDiscovery, stopDiscovery };
