/**
 * OMNIXA CAST — ICE / TURN / STUN Configuration
 * Supports local-only mode (Wi-Fi) and cloud mode (internet casting)
 *
 * Cloud casting requires a TURN server.
 * Free options: Metered.ca, Twilio, Xirsys, or self-hosted coturn.
 *
 * Set in .env:
 *   TURN_URL=turn:your-turn-server.com:3478
 *   TURN_USERNAME=your-username
 *   TURN_CREDENTIAL=your-credential
 *   CASTING_MODE=local | cloud | auto
 */

const CASTING_MODE = process.env.CASTING_MODE || 'auto'; // auto = try P2P, fallback to TURN

function getICEConfig(mode = CASTING_MODE) {
  const stunOnly = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
    ],
    iceTransportPolicy: 'all',
    bundlePolicy: 'max-bundle',
    rtcpMuxPolicy: 'require',
  };

  if (mode === 'local') return stunOnly;

  // Cloud mode — add TURN servers
  const turnServers = [];

  // Primary TURN from env
  if (process.env.TURN_URL) {
    turnServers.push({
      urls: process.env.TURN_URL,
      username:   process.env.TURN_USERNAME   || '',
      credential: process.env.TURN_CREDENTIAL || '',
    });
    // Also try TCP (port 443 for firewalls)
    if (process.env.TURN_URL_TCP) {
      turnServers.push({
        urls: process.env.TURN_URL_TCP,
        username:   process.env.TURN_USERNAME   || '',
        credential: process.env.TURN_CREDENTIAL || '',
      });
    }
  }

  // Metered.ca free TURN (fallback — user gets their own free key)
  if (process.env.METERED_API_KEY) {
    turnServers.push(
      { urls: `turn:a.relay.metered.ca:80`,   username: process.env.METERED_USERNAME, credential: process.env.METERED_CREDENTIAL },
      { urls: `turn:a.relay.metered.ca:443`,  username: process.env.METERED_USERNAME, credential: process.env.METERED_CREDENTIAL },
      { urls: `turns:a.relay.metered.ca:443`, username: process.env.METERED_USERNAME, credential: process.env.METERED_CREDENTIAL },
    );
  }

  return {
    iceServers: [...stunOnly.iceServers, ...turnServers],
    iceTransportPolicy: mode === 'cloud' ? 'relay' : 'all', // 'relay' forces TURN
    bundlePolicy: 'max-bundle',
    rtcpMuxPolicy: 'require',
  };
}

// Timed TURN credentials (more secure — credentials expire after N hours)
function generateTimedCredentials(username, secret, ttlHours = 24) {
  const timestamp = Math.floor(Date.now() / 1000) + (ttlHours * 3600);
  const tempUser  = `${timestamp}:${username}`;
  const crypto    = require('crypto');
  const credential = crypto.createHmac('sha1', secret).update(tempUser).digest('base64');
  return { username: tempUser, credential };
}

// API endpoint helper — client fetches this to get fresh ICE config
function getICEConfigForClient() {
  const config = getICEConfig();
  // Don't expose raw credentials in API — use timed credentials if secret set
  if (process.env.TURN_SECRET && process.env.TURN_URL) {
    const { username, credential } = generateTimedCredentials('omnixa-cast', process.env.TURN_SECRET);
    config.iceServers = config.iceServers.map(s => {
      if (s.urls?.includes('turn:') || s.urls?.includes('turns:')) {
        return { ...s, username, credential };
      }
      return s;
    });
  }
  return config;
}

module.exports = { getICEConfig, getICEConfigForClient, CASTING_MODE };
