# OMNIXA Cast v1.1 — Cross-Platform Screen Casting

Web + Mobile + Smart TV screen casting with WebRTC, Firebase Auth, and mDNS auto-discovery.

## Setup

### 1. Firebase Project
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project
3. Enable **Authentication → Email/Password**
4. Go to Project Settings → Your Apps → Add Web App
5. Copy the config and paste it into `public/shared/firebase.js`

### 2. Run the Server
```bash
npm install
npm start
# or for dev: npm run dev
```

### 3. Access on Your Network
| Device | URL |
|--------|-----|
| Sender (desktop/mobile) | `http://YOUR_LAN_IP:3000/sender` |
| Receiver (desktop/mobile) | `http://YOUR_LAN_IP:3000/receiver` |
| Smart TV | `http://YOUR_LAN_IP:3000/tv` |

Your LAN IP is printed in the console when the server starts.  
**All devices must be on the same Wi-Fi network.**

## TV Authentication Flow (QR Code)
1. Open `http://YOUR_LAN_IP:3000/tv` on the Smart TV browser
2. TV shows a QR code
3. Scan it with your phone → opens auth page
4. Sign in with your Firebase account
5. TV authenticates automatically — no keyboard needed

## Smart TV Compatibility
| Platform | Version | Status |
|----------|---------|--------|
| Samsung Tizen | 5+ | ✅ Supported |
| LG webOS | 6+ | ✅ Supported |
| Android TV | Chrome | ✅ Supported |

## Architecture
- **Signaling**: Node.js + WebSocket (ws)  
- **Discovery**: mDNS via bonjour-service  
- **Media**: WebRTC getDisplayMedia (adaptive bitrate, 4Mbps cap)  
- **Auth**: Firebase Authentication (email/password + QR flow for TV)  

## Bug Fixes in v1.1
- Fixed device ID not available on client (BUG-01)
- Fixed race condition in room creation vs receiver joining (BUG-02)
- Fixed TV reconnect losing userId (BUG-03)
- Fixed Firebase Compat SDK for older TV browsers (RISK-03)
- Fixed stale peer connections via 30s heartbeat (RISK-04)
- Added 4Mbps bitrate cap per WebRTC peer (PERF-01)
- Added room code manual entry on receiver page (UX-01)
