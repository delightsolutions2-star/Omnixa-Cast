# OMNIXA Cast — Android App

React Native app that receives screen casts from the OMNIXA Cast server.

## Features
- Sign in with Firebase email/password
- Auto-discover active casts on the same Wi-Fi
- Join by room code or QR scan
- Full-screen WebRTC stream playback
- Tap to toggle overlay controls

## Setup
```bash
npm install

# Android
npx react-native run-android
```

## Prerequisites
1. Add `google-services.json` from your Firebase Console → Project Settings → Android app
2. OMNIXA Cast server must be running on the same Wi-Fi network
3. Enter the server's LAN IP when prompted (e.g. `http://192.168.1.5:3000`)

## Screens
| Screen | Route |
|--------|-------|
| Login | `Splash` |
| Find Casts | `Discover` |
| Watch Stream | `Receiver` |
| Scan QR | `QRScan` |
