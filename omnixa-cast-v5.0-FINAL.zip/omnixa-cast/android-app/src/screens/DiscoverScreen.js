/**
 * OMNIXA Cast Android — Discover & Join Screen
 * Lists active cast sessions on the same Wi-Fi and allows joining
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, TextInput,
  StyleSheet, ActivityIndicator, Alert, StatusBar
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import auth from '@react-native-firebase/auth';

const DEVICE_EMOJIS = { desktop:'🖥', mobile:'📱', tv_tizen:'📺', tv_webos:'📺', tv_android:'📺' };

export default function DiscoverScreen({ navigation, route }) {
  const [devices, setDevices]   = useState([]);
  const [status, setStatus]     = useState('Connecting…');
  const [connected, setConn]    = useState(false);
  const [roomCode, setRoomCode] = useState('');
  const wsRef = useRef(null);
  const myIdRef = useRef(null);

  // Server URL from route params or last-used
  const serverUrl = route.params?.serverUrl || global.lastServerUrl || '';

  const connectWS = useCallback((url) => {
    if (!url) { navigation.navigate('ServerSelect'); return; }
    global.lastServerUrl = url;
    const user = auth().currentUser;
    if (!user) { navigation.replace('Splash'); return; }

    const wsUrl = url.replace(/^http/, 'ws');
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({ type:'register', payload:{ name:`Android (${user.email})`, deviceType:'mobile', userId:user.uid, authenticated:true } }));
      ws.send(JSON.stringify({ type:'auth_update', payload:{ userId:user.uid } }));
      setConn(true);
      setStatus('Scanning for casts…');
    };

    ws.onmessage = ({ data }) => {
      const msg = JSON.parse(data);
      if (msg.type === 'registered' || msg.type === 'auth_confirmed') {
        myIdRef.current = msg.yourId;
      }
      if (msg.type === 'device_list') {
        // Show senders only (they have active casts)
        const senders = msg.devices.filter(d => d.role === 'sender' && d.id !== myIdRef.current);
        setDevices(senders);
        setStatus(senders.length ? `${senders.length} cast${senders.length>1?'s':''} found` : 'Scanning for casts…');
      }
      if (msg.type === 'room_joined') {
        navigation.navigate('Receiver', { ws: wsRef.current, senderId: null });
      }
      if (msg.type === 'error') {
        Alert.alert('Error', msg.message);
      }
    };

    ws.onerror = () => setStatus('Connection error');
    ws.onclose = () => { setConn(false); setStatus('Disconnected'); };
  }, [navigation]);

  useEffect(() => {
    connectWS(serverUrl);
    return () => wsRef.current?.close();
  }, [connectWS, serverUrl]);

  const joinByDevice = (device) => {
    // Sender's roomId isn't in the device list — user needs to enter it or scan QR
    // We'll navigate to QR scan or manual entry
    Alert.alert(
      `Join ${device.name}'s cast?`,
      'Enter the room code displayed on the sender, or scan their QR code.',
      [
        { text: 'Enter Code', onPress: () => {} },
        { text: 'Scan QR',    onPress: () => navigation.navigate('QRScan', { ws: wsRef.current }) },
        { text: 'Cancel', style: 'cancel' },
      ]
    );
  };

  const joinByCode = () => {
    const code = roomCode.trim().toUpperCase();
    if (!code || !wsRef.current) return;
    wsRef.current.send(JSON.stringify({ type:'join_room', payload:{ roomId:code } }));
  };

  const signOut = async () => {
    wsRef.current?.close();
    await auth().signOut();
    navigation.replace('Splash');
  };

  const renderDevice = ({ item }) => (
    <TouchableOpacity style={styles.deviceCard} onPress={() => joinByDevice(item)} activeOpacity={0.75}>
      <View style={styles.deviceIcon}>
        <Text style={{ fontSize: 24 }}>{DEVICE_EMOJIS[item.type] || '💻'}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.deviceName} numberOfLines={1}>{item.name}</Text>
        <Text style={styles.deviceType}>{item.type.replace('_',' ').toUpperCase()}</Text>
      </View>
      <View style={styles.livePill}>
        <View style={styles.liveDot}/>
        <Text style={styles.liveText}>LIVE</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <LinearGradient colors={['#050709','#0c0f14']} style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="#050709"/>

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.logoRow}>
          <LinearGradient colors={['#00d4ff','#7b5cf0']} style={styles.logoMark}>
            <Text style={styles.logoText}>OX</Text>
          </LinearGradient>
          <Text style={styles.brand}>OMNIXA <Text style={{ color:'#00d4ff' }}>Cast</Text></Text>
        </View>
        <TouchableOpacity onPress={signOut}>
          <Text style={styles.signOutBtn}>Sign out</Text>
        </TouchableOpacity>
      </View>

      {/* Status */}
      <View style={styles.statusRow}>
        <View style={[styles.connDot, { backgroundColor: connected ? '#00e5a0' : '#5a6478' }]}/>
        <Text style={styles.statusText}>{status}</Text>
      </View>

      {/* Manual room code entry */}
      <View style={styles.codeSection}>
        <Text style={styles.sectionLabel}>JOIN BY ROOM CODE</Text>
        <View style={styles.codeRow}>
          <TextInput
            style={styles.codeInput}
            placeholder="e.g. 3F9A2B1C"
            placeholderTextColor="#5a6478"
            value={roomCode}
            onChangeText={t => setRoomCode(t.toUpperCase())}
            autoCapitalize="characters"
            maxLength={8}
          />
          <TouchableOpacity onPress={joinByCode}>
            <LinearGradient colors={['#00d4ff','#7b5cf0']} style={styles.joinBtn}>
              <Text style={styles.joinBtnText}>Join</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.qrBtn} onPress={() => navigation.navigate('QRScan', { ws: wsRef.current })}>
          <Text style={styles.qrBtnText}>📷  Scan QR Code instead</Text>
        </TouchableOpacity>
      </View>

      {/* Active casts */}
      <Text style={[styles.sectionLabel, { paddingHorizontal: 20, marginTop: 8 }]}>ACTIVE CASTS ON YOUR NETWORK</Text>
      {devices.length === 0 ? (
        <View style={styles.emptyState}>
          <ActivityIndicator size="small" color="#5a6478" style={{ marginBottom: 10 }}/>
          <Text style={styles.emptyText}>No active casts detected yet</Text>
          <Text style={styles.emptySubText}>Start casting from a sender device first</Text>
        </View>
      ) : (
        <FlatList
          data={devices}
          keyExtractor={d => d.id}
          renderItem={renderDevice}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}
        />
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root:         { flex: 1 },
  header:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 52, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.06)' },
  logoRow:      { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logoMark:     { width: 32, height: 32, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  logoText:     { color: '#000', fontWeight: '900', fontSize: 12 },
  brand:        { fontSize: 17, fontWeight: '800', color: '#e8ecf0' },
  signOutBtn:   { color: '#5a6478', fontSize: 13 },
  statusRow:    { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 20, paddingVertical: 14 },
  connDot:      { width: 7, height: 7, borderRadius: 4 },
  statusText:   { fontSize: 12, color: '#5a6478' },
  sectionLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1.4, color: '#5a6478', marginBottom: 10 },
  codeSection:  { marginHorizontal: 20, backgroundColor: '#0c0f14', borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)', borderRadius: 16, padding: 16, marginBottom: 20 },
  codeRow:      { flexDirection: 'row', gap: 8, marginBottom: 10 },
  codeInput:    { flex: 1, backgroundColor: '#131720', borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 11, color: '#e8ecf0', fontSize: 15, fontWeight: '700', letterSpacing: 2 },
  joinBtn:      { borderRadius: 10, paddingHorizontal: 20, paddingVertical: 11, alignItems: 'center', justifyContent: 'center' },
  joinBtnText:  { color: '#000', fontWeight: '700', fontSize: 14 },
  qrBtn:        { backgroundColor: '#131720', borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)', borderRadius: 10, paddingVertical: 11, alignItems: 'center' },
  qrBtnText:    { color: '#e8ecf0', fontSize: 13 },
  deviceCard:   { backgroundColor: '#0c0f14', borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)', borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  deviceIcon:   { width: 44, height: 44, borderRadius: 11, backgroundColor: '#131720', borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)', alignItems: 'center', justifyContent: 'center' },
  deviceName:   { color: '#e8ecf0', fontSize: 14, fontWeight: '700', marginBottom: 3 },
  deviceType:   { color: '#5a6478', fontSize: 11 },
  livePill:     { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(255,68,102,0.12)', borderWidth: 1, borderColor: 'rgba(255,68,102,0.3)', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  liveDot:      { width: 5, height: 5, borderRadius: 3, backgroundColor: '#ff4466' },
  liveText:     { color: '#ff4466', fontSize: 10, fontWeight: '700' },
  emptyState:   { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 40 },
  emptyText:    { color: '#5a6478', fontSize: 14, marginBottom: 6 },
  emptySubText: { color: '#3a4358', fontSize: 12 },
});
