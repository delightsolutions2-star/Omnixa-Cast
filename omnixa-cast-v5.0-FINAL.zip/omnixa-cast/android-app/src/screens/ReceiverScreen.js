/**
 * OMNIXA Cast Android — Receiver Screen
 * Displays the incoming WebRTC cast stream full screen
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  StatusBar, Platform, Alert
} from 'react-native';
import { RTCView, RTCPeerConnection, RTCIceCandidate, RTCSessionDescription, mediaDevices } from 'react-native-webrtc';

const ICE = { iceServers: [{ urls:'stun:stun.l.google.com:19302' }] };

export default function ReceiverScreen({ navigation, route }) {
  const { ws } = route.params;
  const pcRef    = useRef(null);
  const [stream, setStream]   = useState(null);
  const [status, setStatus]   = useState('Waiting for cast…');
  const [showCtrl, setShowCtrl] = useState(true);
  const senderId = useRef(null);

  useEffect(() => {
    if (!ws) return;
    const handler = async (e) => {
      const msg = JSON.parse(e.data);
      await handleSignal(msg);
    };
    ws.addEventListener('message', handler);
    // Hide controls after 3s
    const t = setTimeout(() => setShowCtrl(false), 3000);
    return () => { ws.removeEventListener('message', handler); clearTimeout(t); cleanup(); };
  }, [ws]);

  async function handleSignal(msg) {
    switch (msg.type) {
      case 'offer': {
        senderId.current = msg.senderId;
        setStatus('Connecting…');
        const pc = new RTCPeerConnection(ICE);
        pcRef.current = pc;
        pc.ontrack = ({ streams }) => {
          if (streams[0]) { setStream(streams[0]); setStatus(''); }
        };
        pc.onicecandidate = ({ candidate }) => {
          if (candidate && ws) {
            ws.send(JSON.stringify({ type:'ice_candidate', payload:{ targetId:msg.senderId, candidate } }));
          }
        };
        pc.onconnectionstatechange = () => {
          if (['failed','disconnected'].includes(pc.connectionState)) {
            setStatus('Connection lost — returning…');
            setTimeout(() => navigation.goBack(), 2000);
          }
        };
        await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        ws.send(JSON.stringify({ type:'answer', payload:{ targetId:msg.senderId, sdp:pc.localDescription } }));
        break;
      }
      case 'ice_candidate':
        if (pcRef.current && msg.candidate) {
          try { await pcRef.current.addIceCandidate(new RTCIceCandidate(msg.candidate)); } catch {}
        }
        break;
      case 'cast_ended':
        setStatus('Cast ended');
        cleanup();
        setTimeout(() => navigation.goBack(), 1500);
        break;
    }
  }

  function cleanup() {
    if (pcRef.current) { pcRef.current.close(); pcRef.current = null; }
    setStream(null);
  }

  const handleTap = () => {
    setShowCtrl(v => {
      if (!v) setTimeout(() => setShowCtrl(false), 3000);
      return !v;
    });
  };

  return (
    <View style={styles.root}>
      <StatusBar hidden/>
      <TouchableOpacity style={styles.videoWrap} activeOpacity={1} onPress={handleTap}>
        {stream ? (
          <RTCView
            streamURL={stream.toURL()}
            style={styles.video}
            objectFit="contain"
            mirror={false}
          />
        ) : (
          <View style={styles.waiting}>
            <Text style={styles.waitingIcon}>📡</Text>
            <Text style={styles.waitingText}>{status || 'Waiting for cast…'}</Text>
          </View>
        )}
      </TouchableOpacity>

      {/* Overlay controls */}
      {showCtrl && (
        <View style={styles.overlay}>
          <View style={styles.overlayLeft}>
            {stream && <View style={styles.livePill}><Text style={styles.liveText}>● LIVE</Text></View>}
          </View>
          <TouchableOpacity
            style={styles.stopBtn}
            onPress={() => { cleanup(); navigation.goBack(); }}
          >
            <Text style={styles.stopText}>✕ Leave</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root:        { flex: 1, backgroundColor: '#000' },
  videoWrap:   { flex: 1 },
  video:       { flex: 1 },
  waiting:     { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#050709' },
  waitingIcon: { fontSize: 48, marginBottom: 16 },
  waitingText: { color: '#5a6478', fontSize: 16 },
  overlay:     { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, paddingBottom: 32, background: 'linear-gradient(transparent, rgba(0,0,0,0.8))' },
  overlayLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  livePill:    { backgroundColor: 'rgba(255,68,102,0.85)', borderRadius: 6, paddingHorizontal: 10, paddingVertical: 4 },
  liveText:    { color: '#fff', fontSize: 11, fontWeight: '700', letterSpacing: 1 },
  stopBtn:     { backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 8, paddingHorizontal: 16, paddingVertical: 8 },
  stopText:    { color: '#fff', fontSize: 13, fontWeight: '600' },
});
