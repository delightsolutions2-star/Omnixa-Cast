/**
 * OMNIXA Cast Android — Splash / Login Screen
 */
import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator, KeyboardAvoidingView,
  Platform, Alert
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import auth from '@react-native-firebase/auth';

export default function SplashScreen({ navigation }) {
  const [email, setEmail]       = useState('');
  const [pass, setPass]         = useState('');
  const [loading, setLoading]   = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const unsub = auth().onAuthStateChanged(user => {
      setChecking(false);
      if (user) navigation.replace('Discover');
    });
    return unsub;
  }, []);

  const signIn = async () => {
    if (!email.trim() || !pass) return;
    setLoading(true);
    try {
      await auth().signInWithEmailAndPassword(email.trim(), pass);
      // onAuthStateChanged handles navigation
    } catch (e) {
      Alert.alert('Sign In Failed', e.message.replace('Firebase: ', ''));
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#00d4ff" />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#050709','#0c0f14']} style={styles.bg}>
        {/* Grid overlay */}
        <View style={styles.card}>
          {/* Logo */}
          <LinearGradient colors={['#00d4ff','#7b5cf0']} style={styles.logoMark}>
            <Text style={styles.logoText}>OX</Text>
          </LinearGradient>
          <Text style={styles.brandName}>OMNIXA <Text style={styles.brandAccent}>Cast</Text></Text>
          <Text style={styles.subtitle}>Sign in to receive screen casts{'\n'}on this Android device</Text>

          <TextInput
            style={styles.input}
            placeholder="Email address"
            placeholderTextColor="#5a6478"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#5a6478"
            value={pass}
            onChangeText={setPass}
            secureTextEntry
          />

          <TouchableOpacity onPress={signIn} disabled={loading} activeOpacity={0.85}>
            <LinearGradient colors={['#00d4ff','#7b5cf0']} style={styles.btnPrimary}>
              {loading
                ? <ActivityIndicator size="small" color="#000"/>
                : <Text style={styles.btnText}>Sign In & Connect</Text>}
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('QRScan')} style={styles.btnSecondary}>
            <Text style={styles.btnSecText}>📷  Scan QR to join a cast</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root:        { flex: 1 },
  bg:          { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  center:      { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#050709' },
  card:        { backgroundColor: '#0c0f14', borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)', borderRadius: 24, padding: 32, width: '100%', maxWidth: 380, alignItems: 'center' },
  logoMark:    { width: 56, height: 56, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  logoText:    { color: '#000', fontWeight: '900', fontSize: 18 },
  brandName:   { fontSize: 22, fontWeight: '800', color: '#e8ecf0', marginBottom: 8, letterSpacing: 0.5 },
  brandAccent: { color: '#00d4ff' },
  subtitle:    { color: '#5a6478', fontSize: 14, textAlign: 'center', lineHeight: 22, marginBottom: 28 },
  input:       { backgroundColor: '#131720', borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 13, color: '#e8ecf0', fontSize: 14, width: '100%', marginBottom: 12 },
  btnPrimary:  { borderRadius: 12, paddingVertical: 15, alignItems: 'center', width: '100%', marginBottom: 12 },
  btnText:     { color: '#000', fontWeight: '700', fontSize: 15 },
  btnSecondary:{ borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', borderRadius: 12, paddingVertical: 13, alignItems: 'center', width: '100%', backgroundColor: '#131720' },
  btnSecText:  { color: '#e8ecf0', fontSize: 14 },
});
