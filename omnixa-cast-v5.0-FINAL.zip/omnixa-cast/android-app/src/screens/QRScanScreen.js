/**
 * OMNIXA Cast Android — QR Scanner Screen
 * Scans either a room join QR or a TV auth QR
 */
import React, { useState } from 'react';
import { View, Text, StyleSheet, Alert, StatusBar } from 'react-native';
import { CameraKit } from 'react-native-camera-kit';

export default function QRScanScreen({ navigation, route }) {
  const [scanned, setScanned] = useState(false);
  const ws = route.params?.ws;

  const onScan = ({ nativeEvent }) => {
    if (scanned) return;
    const url = nativeEvent?.codeStringValue || '';
    if (!url) return;
    setScanned(true);

    // Detect QR type from URL pattern
    if (url.includes('/tv-auth?token=')) {
      // TV auth QR — open in browser / handle directly
      navigation.replace('TVAuth', { url });
    } else if (url.includes('/receiver?room=')) {
      // Room join QR
      const roomId = new URL(url).searchParams.get('room');
      if (ws && roomId) {
        ws.send(JSON.stringify({ type: 'join_room', payload: { roomId } }));
        navigation.replace('Receiver', { ws });
      } else {
        // Open URL directly (user might not be logged in yet)
        navigation.replace('Discover', { serverUrl: url.split('/receiver')[0] });
      }
    } else {
      Alert.alert('Unknown QR', 'This QR code is not recognized.', [{ text: 'OK', onPress: () => setScanned(false) }]);
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar hidden/>
      <CameraKit
        style={StyleSheet.absoluteFill}
        scanBarcode
        onReadCode={onScan}
        showFrame
        laserColor="#00d4ff"
        frameColor="#00d4ff"
      />
      <View style={styles.overlay}>
        <Text style={styles.title}>Scan QR Code</Text>
        <Text style={styles.sub}>Point at the QR on the sender screen or TV</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root:    { flex: 1, backgroundColor: '#000' },
  overlay: { position: 'absolute', top: 60, left: 0, right: 0, alignItems: 'center' },
  title:   { color: '#fff', fontSize: 20, fontWeight: '800', marginBottom: 8 },
  sub:     { color: 'rgba(255,255,255,0.6)', fontSize: 13 },
});
