/**
 * OMNIXA Cast Android — App Entry + Navigation
 */
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import SplashScreen    from './screens/SplashScreen';
import DiscoverScreen  from './screens/DiscoverScreen';
import ReceiverScreen  from './screens/ReceiverScreen';
import QRScanScreen    from './screens/QRScanScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'fade' }}>
        <Stack.Screen name="Splash"    component={SplashScreen}    />
        <Stack.Screen name="Discover"  component={DiscoverScreen}  />
        <Stack.Screen name="Receiver"  component={ReceiverScreen}  />
        <Stack.Screen name="QRScan"    component={QRScanScreen}    />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
