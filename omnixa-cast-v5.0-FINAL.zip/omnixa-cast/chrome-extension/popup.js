/**
 * OMNIXA Cast Extension — Popup Script
 * Talks to background.js via chrome.runtime.sendMessage
 */

// ── Firebase (loaded inline in popup for auth) ───────────────────────────────
// We use the Firebase SDK CDN via importScripts is not allowed in popup,
// so we use fetch-based auth against Firebase REST API instead
const FB_AUTH_URL = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=';
let apiKey = '';
let userId = '';
let userEmail = '';
let castMode = 'tab';
let casting = false;
let viewers = {};
let joinQrUrl = '';

// ── Init ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Load saved server URL
  const saved = await chrome.storage.local.get(['serverUrl', 'userId', 'userEmail', 'apiKey']);
  if (saved.serverUrl) document.getElementById('server-url').value = saved.serverUrl;
  if (saved.userId) { userId = saved.userId; userEmail = saved.userEmail || ''; apiKey = saved.apiKey || ''; }
  if (saved.apiKey) apiKey = saved.apiKey;

  // Get current state from background
  chrome.runtime.sendMessage({ action: 'get_state' }, state => {
    if (chrome.runtime.lastError) return;
    updateUI(state);
  });

  // Listen to background events
  chrome.runtime.onMessage.addListener(handleBgEvent);

  // Show auth row if we have a server URL saved
  if (saved.serverUrl) showAuthRow();
});

// ── Background event handler ──────────────────────────────────────────────────
function handleBgEvent(msg) {
  switch (msg.event) {
    case 'connected':
      setStatus('Connected to server', 'ok');
      document.getElementById('conn-dot').className = 'conn-dot on';
      document.getElementById('cast-section').style.display = 'block';
      document.getElementById('connect-btn').textContent = 'Reconnect';
      break;

    case 'disconnected':
      setStatus('Disconnected', '');
      document.getElementById('conn-dot').className = 'conn-dot';
      document.getElementById('cast-section').style.display = 'none';
      break;

    case 'registered':
      setStatus(`Signed in as ${userEmail}`, 'ok');
      break;

    case 'device_list':
      // Available to connect — not shown in popup (simplified)
      break;

    case 'room_created':
      document.getElementById('ext-room-code').textContent = `Room: ${msg.roomId}`;
      loadJoinQR(msg.roomId);
      break;

    case 'cast_started':
      casting = true;
      document.getElementById('live-panel').classList.add('visible');
      document.getElementById('cast-btn').className = 'btn btn-danger';
      document.getElementById('cast-btn').textContent = '■ Stop Cast';
      document.getElementById('conn-dot').className = 'conn-dot casting';
      setStatus('Casting live…', 'live');
      break;

    case 'cast_stopped':
      casting = false;
      viewers = {};
      document.getElementById('live-panel').classList.remove('visible');
      document.getElementById('cast-btn').className = 'btn btn-accent';
      document.getElementById('cast-btn').textContent = '▶ Start Cast';
      document.getElementById('conn-dot').className = 'conn-dot on';
      document.getElementById('viewers-row').innerHTML = '<div class="no-viewers" id="no-viewers">Waiting for viewers…</div>';
      document.getElementById('qr-mini').style.display = 'none';
      setStatus('Cast stopped', '');
      break;

    case 'receiver_joined':
      viewers[msg.receiverId] = msg.receiverName;
      renderViewers();
      break;

    case 'receiver_left':
      delete viewers[msg.receiverId];
      renderViewers();
      break;

    case 'error':
      setStatus(msg.msg, 'err');
      break;
  }
}

// ── Server connect ─────────────────────────────────────────────────────────────
window.connectServer = () => {
  const url = document.getElementById('server-url').value.trim();
  if (!url) return;
  chrome.storage.local.set({ serverUrl: url });
  showAuthRow();
  setStatus('Enter credentials to sign in', '');
};

function showAuthRow() {
  document.getElementById('auth-row').style.display = 'flex';
}

// ── Firebase REST auth (works in extension popup without SDK) ─────────────────
window.extSignIn = async () => {
  const email = document.getElementById('ext-email').value.trim();
  const pass  = document.getElementById('ext-pass').value;
  const statusEl = document.getElementById('auth-status');
  statusEl.className = 'auth-status';
  statusEl.textContent = 'Signing in…';

  // We need the Firebase API key — fetch it from the server's firebase.js
  const serverUrl = document.getElementById('server-url').value.trim();
  try {
    if (!apiKey) {
      const r = await fetch(`${serverUrl}/shared/firebase.js`);
      const text = await r.text();
      const match = text.match(/apiKey['":\s]+['"]([^'"]+)['"]/);
      if (match) { apiKey = match[1]; chrome.storage.local.set({ apiKey }); }
    }

    const res = await fetch(`${FB_AUTH_URL}${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: pass, returnSecureToken: true })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);

    userId = data.localId;
    userEmail = data.email;
    chrome.storage.local.set({ userId, userEmail, apiKey });

    statusEl.className = 'auth-status ok';
    statusEl.textContent = `✓ Signed in as ${email}`;

    // Connect WebSocket
    chrome.runtime.sendMessage({
      action: 'connect',
      serverUrl: serverUrl.replace(/\/$/, ''),
      userId, userEmail
    });

  } catch (e) {
    statusEl.className = 'auth-status err';
    statusEl.textContent = '✗ ' + e.message;
  }
};

// ── Cast controls ─────────────────────────────────────────────────────────────
window.setMode = (mode) => {
  castMode = mode;
  document.getElementById('mode-tab').classList.toggle('active', mode === 'tab');
  document.getElementById('mode-screen').classList.toggle('active', mode === 'screen');
};

window.toggleCast = () => {
  if (casting) {
    chrome.runtime.sendMessage({ action: 'stop_cast' });
  } else {
    chrome.runtime.sendMessage({ action: 'start_cast', mode: castMode });
  }
};

// ── Viewers list ──────────────────────────────────────────────────────────────
function renderViewers() {
  const row = document.getElementById('viewers-row');
  const ids = Object.keys(viewers);
  if (!ids.length) {
    row.innerHTML = '<div class="no-viewers" id="no-viewers">Waiting for viewers…</div>';
    return;
  }
  row.innerHTML = ids.map(id =>
    `<div class="viewer-item"><div class="viewer-dot"></div>${viewers[id]}</div>`
  ).join('');
}

// ── Join QR in popup ──────────────────────────────────────────────────────────
async function loadJoinQR(roomId) {
  const serverUrl = (await chrome.storage.local.get('serverUrl')).serverUrl || '';
  try {
    const res  = await fetch(`${serverUrl}/api/room-qr/${roomId}`);
    const data = await res.json();
    joinQrUrl = data.url;
    const img = document.getElementById('ext-qr-img');
    img.src = data.qr;
    document.getElementById('qr-mini').style.display = 'block';
  } catch {}
}

// ── Status bar ────────────────────────────────────────────────────────────────
function setStatus(msg, type) {
  const el = document.getElementById('status-bar');
  el.textContent = msg;
  el.style.color = type === 'ok' ? 'var(--green)' : type === 'err' ? 'var(--red)' : type === 'live' ? 'var(--red)' : 'var(--muted)';
}

function updateUI(state) {
  if (!state) return;
  if (state.connected) {
    document.getElementById('conn-dot').className = 'conn-dot on';
    document.getElementById('cast-section').style.display = 'block';
    setStatus(state.casting ? 'Casting live…' : 'Connected', state.casting ? 'live' : 'ok');
  }
  if (state.casting) {
    casting = true;
    document.getElementById('live-panel').classList.add('visible');
    document.getElementById('cast-btn').className = 'btn btn-danger';
    document.getElementById('cast-btn').textContent = '■ Stop Cast';
    document.getElementById('conn-dot').className = 'conn-dot casting';
    if (state.roomId) document.getElementById('ext-room-code').textContent = `Room: ${state.roomId}`;
  }
  if (state.serverUrl) document.getElementById('server-url').value = state.serverUrl;
}
