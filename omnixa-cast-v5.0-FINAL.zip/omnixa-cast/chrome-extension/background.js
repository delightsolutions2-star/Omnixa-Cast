/**
 * OMNIXA Cast — Chrome Extension Background Service Worker
 * Handles: tab capture, WebSocket signaling, WebRTC peer connections
 */

let ws = null;
let stream = null;
let peers = {};
let myId = null;
let roomId = null;
let casting = false;
let serverUrl = '';

const ICE = { iceServers: [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' }
]};

// ── Message handler from popup ───────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.action) {

    case 'get_state':
      sendResponse({ casting, myId, roomId, serverUrl, connected: ws?.readyState === 1 });
      break;

    case 'connect':
      serverUrl = msg.serverUrl;
      connectWS(msg.serverUrl, msg.userId, msg.userEmail);
      sendResponse({ ok: true });
      break;

    case 'start_cast':
      startCast(msg.mode); // mode: 'tab' | 'screen'
      sendResponse({ ok: true });
      break;

    case 'stop_cast':
      stopCast();
      sendResponse({ ok: true });
      break;

    case 'disconnect':
      if (ws) ws.close();
      sendResponse({ ok: true });
      break;
  }
  return true; // keep async channel open
});

// ── WebSocket ────────────────────────────────────────────────────────────────
function connectWS(url, userId, userEmail) {
  if (ws) ws.close();
  const wsUrl = url.replace(/^http/, 'ws');
  ws = new WebSocket(wsUrl);

  ws.onopen = () => {
    ws.send(JSON.stringify({
      type: 'register',
      payload: { name: `Chrome (${userEmail})`, deviceType: 'desktop', userId, authenticated: true }
    }));
    ws.send(JSON.stringify({ type: 'auth_update', payload: { userId } }));
    notifyPopup({ event: 'connected' });
  };

  ws.onmessage = ({ data }) => handleSignal(JSON.parse(data));

  ws.onclose = () => {
    notifyPopup({ event: 'disconnected' });
    if (casting) stopCast();
  };

  ws.onerror = () => notifyPopup({ event: 'error', msg: 'WebSocket connection failed' });
}

function send(data) {
  if (ws?.readyState === 1) ws.send(JSON.stringify(data));
}

async function handleSignal(msg) {
  switch (msg.type) {
    case 'registered':
    case 'auth_confirmed':
      myId = msg.yourId;
      notifyPopup({ event: 'registered', myId });
      break;

    case 'device_list':
      notifyPopup({ event: 'device_list', devices: msg.devices.filter(d => d.id !== myId) });
      break;

    case 'room_created':
      roomId = msg.roomId;
      notifyPopup({ event: 'room_created', roomId });
      break;

    case 'receiver_joined': {
      const { receiverId, receiverName } = msg;
      if (casting && stream) await createOffer(receiverId);
      notifyPopup({ event: 'receiver_joined', receiverId, receiverName });
      break;
    }

    case 'receiver_left':
      closePeer(msg.receiverId);
      notifyPopup({ event: 'receiver_left', receiverId: msg.receiverId });
      break;

    case 'answer': {
      const pc = peers[msg.receiverId]?.pc;
      if (pc) await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
      break;
    }

    case 'ice_candidate': {
      const pc = peers[msg.fromId]?.pc;
      if (pc && msg.candidate) {
        try { await pc.addIceCandidate(new RTCIceCandidate(msg.candidate)); } catch {}
      }
      break;
    }

    case 'error':
      notifyPopup({ event: 'error', msg: msg.message });
      break;
  }
}

// ── Screen/Tab Capture ───────────────────────────────────────────────────────
async function startCast(mode) {
  try {
    if (mode === 'tab') {
      // Use Chrome tabCapture API for current tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      stream = await new Promise((resolve, reject) => {
        chrome.tabCapture.capture({ video: true, audio: false }, s => {
          if (chrome.runtime.lastError || !s) reject(new Error(chrome.runtime.lastError?.message || 'Tab capture failed'));
          else resolve(s);
        });
      });
    } else {
      // Full screen / window selection
      stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 30 }, audio: false });
    }

    stream.getVideoTracks()[0].onended = stopCast;
    casting = true;
    send({ type: 'create_room', payload: {} });
    notifyPopup({ event: 'cast_started' });

    chrome.action.setBadgeText({ text: 'ON' });
    chrome.action.setBadgeBackgroundColor({ color: '#00e5a0' });
  } catch (e) {
    notifyPopup({ event: 'error', msg: e.message });
  }
}

async function createOffer(receiverId) {
  if (peers[receiverId]) return;
  const pc = new RTCPeerConnection(ICE);
  peers[receiverId] = { pc };
  stream.getTracks().forEach(t => pc.addTrack(t, stream));
  pc.onicecandidate = ({ candidate }) => {
    if (candidate) send({ type: 'ice_candidate', payload: { targetId: receiverId, candidate } });
  };
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === 'connected') applyBitrateCap(pc);
    if (['failed','disconnected'].includes(pc.connectionState)) closePeer(receiverId);
  };
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  send({ type: 'offer', payload: { targetId: receiverId, sdp: pc.localDescription } });
}

async function applyBitrateCap(pc) {
  for (const sender of pc.getSenders()) {
    if (sender.track?.kind === 'video') {
      const params = sender.getParameters();
      if (!params.encodings) params.encodings = [{}];
      params.encodings[0].maxBitrate = 4_000_000;
      try { await sender.setParameters(params); } catch {}
    }
  }
}

function closePeer(id) {
  if (peers[id]) { try { peers[id].pc.close(); } catch {} delete peers[id]; }
}

function stopCast() {
  if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; }
  Object.keys(peers).forEach(closePeer);
  casting = false; roomId = null;
  send({ type: 'leave_room', payload: {} });
  notifyPopup({ event: 'cast_stopped' });
  chrome.action.setBadgeText({ text: '' });
}

// ── Notify popup (if open) ───────────────────────────────────────────────────
function notifyPopup(data) {
  chrome.runtime.sendMessage(data).catch(() => {}); // ignore if popup closed
}
