module.exports = {
  apps: [{
    name:     "omnixa-cast",
    script:   "server/index.js",
    cwd:      "/opt/omnixa-cast",
    instances: 1,
    exec_mode: "fork",
    watch:    false,
    max_memory_restart: "512M",
    env_production: { NODE_ENV:"production", PORT:3000, CASTING_MODE:"auto" },
    error_file: "/var/log/omnixa-cast/error.log",
    out_file:   "/var/log/omnixa-cast/out.log",
    restart_delay: 5000,
    max_restarts:  10,
  }]
};
