#!/bin/bash
# OMNIXA Cast — Production VPS Setup (Ubuntu 22.04)
set -e
DOMAIN="${1:-cast.yourdomain.com}"
EMAIL="${2:-admin@yourdomain.com}"
echo "Setting up OMNIXA Cast at $DOMAIN..."
apt-get update && apt-get upgrade -y
apt-get install -y curl git nginx certbot python3-certbot-nginx ufw
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
npm install -g pm2
ufw allow OpenSSH
ufw allow "Nginx Full"
ufw allow 3478/tcp && ufw allow 3478/udp
ufw --force enable
sed "s/cast.yourdomain.com/$DOMAIN/g" deploy/nginx/omnixa-cast.conf > /etc/nginx/sites-available/$DOMAIN
ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
certbot --nginx -d $DOMAIN --email $EMAIL --agree-tos --non-interactive
pm2 start deploy/scripts/ecosystem.config.js --env production
pm2 save && pm2 startup
echo "✅ Live at https://$DOMAIN — edit .env then: pm2 restart omnixa-cast"
