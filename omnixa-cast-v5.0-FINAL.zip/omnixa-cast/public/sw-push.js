/**
 * OMNIXA Cast — Push Service Worker
 * Handles background push notifications from FCM
 */

importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging-compat.js');

// Initialize Firebase in SW (uses same config as app)
// Config is injected by the server at /sw-config endpoint
self.addEventListener('install',  () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

// Handle push events
self.addEventListener('push', event => {
  if (!event.data) return;
  const data    = event.data.json();
  const title   = data.title   || 'OMNIXA Cast';
  const options = {
    body:    data.body    || 'You have a notification',
    icon:    data.icon    || '/public/assets/icons/icon-192.png',
    badge:   data.badge   || '/public/assets/icons/badge-72.png',
    data:    data.data    || {},
    actions: data.actions || [{ action: 'join', title: 'Join Cast' }],
    requireInteraction: true,
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

// Handle notification click
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = event.notification.data?.url || '/';
  if (event.action === 'join' || !event.action) {
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => {
        const existing = clients.find(c => c.url === url);
        if (existing) return existing.focus();
        return self.clients.openWindow(url);
      })
    );
  }
});
