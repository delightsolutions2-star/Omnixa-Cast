/**
 * OMNIXA Cast — i18n Strings
 * Supported: en, fr, es, sw (Swahili)
 * Usage: t('key') returns string in detected/selected language
 */
const STRINGS = {
  en: {
    welcome: 'Welcome back',
    signIn: 'Sign In',
    signOut: 'Sign out',
    startCast: '▶ Start Cast',
    stopCast: '■ Stop Cast',
    casting: 'Casting live',
    readyToCast: 'Ready to cast',
    selectDevices: 'Select receivers below, then click Start',
    availableDevices: 'Available Devices',
    activeReceivers: 'Active Receivers',
    waitingForCast: 'Waiting for a sender to cast to this device',
    readyToReceive: 'Ready to Receive',
    joinCast: 'Join a Cast',
    joinRoom: 'Join Room',
    roomCode: 'Room code (optional)',
    scanQR: 'Scan to Sign In',
    authTV: 'Authenticate TV',
    castEnded: 'Cast ended',
    noDevices: 'Scanning your network for devices…',
    noReceivers: 'No devices connected yet',
    connected: 'Connected to cast network',
    disconnected: 'Disconnected from server',
    copiedLink: '✓ Copied!',
    copyLink: 'Copy Link',
    quickJoin: 'Quick Join',
    scanToJoin: 'Scan to join this cast',
    email: 'Email address',
    password: 'Password',
    signInConnect: 'Sign In & Connect',
    authorizeTV: 'Authorize TV',
    authorized: 'TV authenticated successfully!',
    liveCount: (n) => `${n} viewer${n !== 1 ? 's' : ''}`,
  },
  fr: {
    welcome: 'Bon retour',
    signIn: 'Se connecter',
    signOut: 'Se déconnecter',
    startCast: '▶ Démarrer la diffusion',
    stopCast: '■ Arrêter la diffusion',
    casting: 'Diffusion en direct',
    readyToCast: 'Prêt à diffuser',
    selectDevices: 'Sélectionnez des appareils puis cliquez Démarrer',
    availableDevices: 'Appareils disponibles',
    activeReceivers: 'Récepteurs actifs',
    waitingForCast: 'En attente d\'une diffusion sur cet appareil',
    readyToReceive: 'Prêt à recevoir',
    joinCast: 'Rejoindre une diffusion',
    joinRoom: 'Rejoindre',
    roomCode: 'Code de salle (optionnel)',
    scanQR: 'Scanner pour se connecter',
    authTV: 'Authentifier la TV',
    castEnded: 'Diffusion terminée',
    noDevices: 'Recherche d\'appareils sur votre réseau…',
    noReceivers: 'Aucun appareil connecté',
    connected: 'Connecté au réseau Cast',
    disconnected: 'Déconnecté du serveur',
    copiedLink: '✓ Copié !',
    copyLink: 'Copier le lien',
    quickJoin: 'Accès rapide',
    scanToJoin: 'Scanner pour rejoindre cette diffusion',
    email: 'Adresse email',
    password: 'Mot de passe',
    signInConnect: 'Se connecter',
    authorizeTV: 'Autoriser la TV',
    authorized: 'TV authentifiée avec succès !',
    liveCount: (n) => `${n} spectateur${n !== 1 ? 's' : ''}`,
  },
  es: {
    welcome: 'Bienvenido de nuevo',
    signIn: 'Iniciar sesión',
    signOut: 'Cerrar sesión',
    startCast: '▶ Iniciar transmisión',
    stopCast: '■ Detener transmisión',
    casting: 'Transmitiendo en vivo',
    readyToCast: 'Listo para transmitir',
    selectDevices: 'Selecciona dispositivos y haz clic en Iniciar',
    availableDevices: 'Dispositivos disponibles',
    activeReceivers: 'Receptores activos',
    waitingForCast: 'Esperando una transmisión en este dispositivo',
    readyToReceive: 'Listo para recibir',
    joinCast: 'Unirse a una transmisión',
    joinRoom: 'Unirse',
    roomCode: 'Código de sala (opcional)',
    scanQR: 'Escanear para iniciar sesión',
    authTV: 'Autenticar TV',
    castEnded: 'Transmisión finalizada',
    noDevices: 'Buscando dispositivos en tu red…',
    noReceivers: 'Ningún dispositivo conectado',
    connected: 'Conectado a la red Cast',
    disconnected: 'Desconectado del servidor',
    copiedLink: '✓ ¡Copiado!',
    copyLink: 'Copiar enlace',
    quickJoin: 'Acceso rápido',
    scanToJoin: 'Escanear para unirte a esta transmisión',
    email: 'Correo electrónico',
    password: 'Contraseña',
    signInConnect: 'Iniciar sesión',
    authorizeTV: 'Autorizar TV',
    authorized: '¡TV autenticada con éxito!',
    liveCount: (n) => `${n} espectador${n !== 1 ? 'es' : ''}`,
  },
  sw: {
    welcome: 'Karibu tena',
    signIn: 'Ingia',
    signOut: 'Toka',
    startCast: '▶ Anza Kutangaza',
    stopCast: '■ Simama Kutangaza',
    casting: 'Inatangaza moja kwa moja',
    readyToCast: 'Uko tayari kutangaza',
    selectDevices: 'Chagua vifaa halafu bonyeza Anza',
    availableDevices: 'Vifaa Vilivyopo',
    activeReceivers: 'Wapokeaji Wanaofanya Kazi',
    waitingForCast: 'Inasubiri utangazaji kwenye kifaa hiki',
    readyToReceive: 'Tayari Kupokea',
    joinCast: 'Jiunge na Utangazaji',
    joinRoom: 'Jiunge',
    roomCode: 'Nambari ya chumba (hiari)',
    scanQR: 'Scan Kuingia',
    authTV: 'Thibitisha TV',
    castEnded: 'Utangazaji umekwisha',
    noDevices: 'Inatafuta vifaa kwenye mtandao wako…',
    noReceivers: 'Hakuna kifaa kilichounganishwa',
    connected: 'Imeunganishwa kwenye mtandao wa Cast',
    disconnected: 'Imekatika kutoka kwa seva',
    copiedLink: '✓ Imenakiliwa!',
    copyLink: 'Nakili Kiungo',
    quickJoin: 'Jiunge Haraka',
    scanToJoin: 'Scan kujiunge na utangazaji huu',
    email: 'Anwani ya barua pepe',
    password: 'Nenosiri',
    signInConnect: 'Ingia na Unganisha',
    authorizeTV: 'Idhini TV',
    authorized: 'TV imethibitishwa!',
    liveCount: (n) => `Watazamaji ${n}`,
  },
};

// Auto-detect browser language
const LANG_MAP = { fr:'fr', es:'es', sw:'sw', en:'en' };
function detectLang() {
  const nav = (navigator.language || navigator.userLanguage || 'en').slice(0,2).toLowerCase();
  return LANG_MAP[nav] || 'en';
}

let _lang = localStorage.getItem('omnixa_lang') || detectLang();

function t(key) {
  const str = STRINGS[_lang]?.[key] || STRINGS.en[key];
  return typeof str === 'function' ? str : (str || key);
}
function setLang(lang) {
  _lang = STRINGS[lang] ? lang : 'en';
  localStorage.setItem('omnixa_lang', _lang);
}
function getLang() { return _lang; }
function getAvailableLangs() { return Object.keys(STRINGS); }

export { t, setLang, getLang, getAvailableLangs };
