/**
 * OMNIXA CAST — Chat Panel Web Component (Phase 6)
 * Renders a full chat UI that works as sender (Q&A host) or receiver (participant)
 * 
 * Usage:
 *   import { ChatPanel } from '/shared/chat-panel.js';
 *   const chat = new ChatPanel(ws, { isSender: true, userName: 'Host' });
 *   document.body.appendChild(chat.el);
 *   chat.open();
 */

const QUICK_REACTIONS = ['👍','❤️','🔥','😂','👏','🤔'];

class ChatPanel {
  constructor(ws, opts = {}) {
    this.ws       = ws;
    this.isSender = opts.isSender || false;
    this.userName = opts.userName || 'Guest';
    this.userId   = opts.userId   || 'anon';
    this.messages = [];
    this.open_    = false;
    this.unread   = 0;
    this._build();
    this._wire();
  }

  // ── Build DOM ──────────────────────────────────────────────────────────────
  _build() {
    const el = document.createElement('div');
    el.innerHTML = `
<style>
  .cp-wrap{
    position:fixed; bottom:24px; right:24px; z-index:200;
    display:flex; flex-direction:column; align-items:flex-end; gap:10px;
    font-family:'DM Sans',sans-serif;
  }
  .cp-panel{
    width:320px; height:480px; background:#0c0f14; border:1px solid rgba(255,255,255,.08);
    border-radius:18px; display:none; flex-direction:column; overflow:hidden;
    box-shadow:0 24px 60px rgba(0,0,0,.6);
    animation:cpSlide .25s ease;
  }
  .cp-panel.open{ display:flex; }
  @keyframes cpSlide{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
  .cp-head{
    display:flex; align-items:center; justify-content:space-between;
    padding:14px 16px; border-bottom:1px solid rgba(255,255,255,.06);
    flex-shrink:0;
  }
  .cp-head-title{ font-family:'Syne',sans-serif; font-size:14px; font-weight:700; color:#e8ecf0; }
  .cp-head-sub  { font-size:11px; color:#5a6478; }
  .cp-close{ background:none; border:none; color:#5a6478; font-size:16px; cursor:pointer; padding:4px; }
  .cp-close:hover{ color:#e8ecf0; }
  .cp-tabs{ display:flex; border-bottom:1px solid rgba(255,255,255,.06); flex-shrink:0; }
  .cp-tab{
    flex:1; padding:9px; text-align:center; font-size:11px; font-weight:700;
    color:#5a6478; cursor:pointer; border:none; background:none;
    border-bottom:2px solid transparent; transition:all .2s; letter-spacing:.05em;
    font-family:'Syne',sans-serif;
  }
  .cp-tab.active{ color:#00d4ff; border-bottom-color:#00d4ff; }
  .cp-messages{
    flex:1; overflow-y:auto; padding:12px; display:flex;
    flex-direction:column; gap:8px; scroll-behavior:smooth;
  }
  .cp-messages::-webkit-scrollbar{ width:4px; }
  .cp-messages::-webkit-scrollbar-track{ background:transparent; }
  .cp-messages::-webkit-scrollbar-thumb{ background:rgba(255,255,255,.1); border-radius:2px; }
  .cp-msg{ display:flex; flex-direction:column; gap:2px; }
  .cp-msg.mine .cp-bubble{ align-self:flex-end; background:rgba(0,212,255,.12); border-color:rgba(0,212,255,.2); }
  .cp-msg-name{ font-size:10px; color:#5a6478; margin-left:2px; }
  .cp-bubble{
    background:#131720; border:1px solid rgba(255,255,255,.06);
    border-radius:12px; padding:8px 12px; font-size:13px; color:#e8ecf0;
    align-self:flex-start; max-width:90%; line-height:1.5; position:relative;
  }
  .cp-bubble.question{ border-color:rgba(123,92,240,.3); background:rgba(123,92,240,.08); }
  .cp-bubble.answered{ opacity:.6; }
  .cp-bubble.system{ background:rgba(0,229,160,.06); border-color:rgba(0,229,160,.15); color:#00e5a0; font-size:11px; text-align:center; width:100%; border-radius:8px; }
  .cp-msg-foot{ display:flex; align-items:center; gap:6px; margin-top:2px; }
  .cp-ts{ font-size:10px; color:#5a6478; }
  .cp-react-row{ display:flex; gap:4px; flex-wrap:wrap; }
  .cp-react-chip{
    display:flex; align-items:center; gap:3px; padding:2px 6px;
    background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.08);
    border-radius:10px; font-size:11px; cursor:pointer; transition:background .2s;
  }
  .cp-react-chip:hover{ background:rgba(255,255,255,.1); }
  .cp-react-count{ color:#5a6478; font-size:10px; }
  .cp-answered-badge{
    font-size:10px; color:#00e5a0; background:rgba(0,229,160,.1);
    border:1px solid rgba(0,229,160,.2); border-radius:4px; padding:1px 6px;
  }
  .cp-answer-btn{
    font-size:10px; color:#a78bfa; background:none; border:1px solid rgba(123,92,240,.25);
    border-radius:4px; padding:2px 7px; cursor:pointer; font-family:'DM Sans',sans-serif;
    transition:background .2s;
  }
  .cp-answer-btn:hover{ background:rgba(123,92,240,.1); }
  .cp-quick-reacts{
    display:flex; gap:4px; padding:8px 12px; border-top:1px solid rgba(255,255,255,.05);
    flex-shrink:0;
  }
  .cp-qr-btn{
    flex:1; padding:6px; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.07);
    border-radius:8px; font-size:16px; cursor:pointer; transition:background .2s; text-align:center;
  }
  .cp-qr-btn:hover{ background:rgba(255,255,255,.1); }
  .cp-input-row{
    display:flex; gap:8px; padding:12px; border-top:1px solid rgba(255,255,255,.06);
    flex-shrink:0;
  }
  .cp-input-wrap{ flex:1; display:flex; flex-direction:column; gap:4px; }
  .cp-type-row{ display:flex; gap:4px; }
  .cp-type-btn{
    padding:3px 8px; border-radius:5px; border:1px solid rgba(255,255,255,.07);
    background:none; color:#5a6478; font-size:10px; cursor:pointer; font-family:'DM Sans',sans-serif;
    transition:all .2s;
  }
  .cp-type-btn.active{ border-color:rgba(123,92,240,.4); color:#a78bfa; background:rgba(123,92,240,.08); }
  .cp-textarea{
    background:#131720; border:1px solid rgba(255,255,255,.07); border-radius:10px;
    padding:9px 12px; color:#e8ecf0; font-size:13px; resize:none; outline:none;
    font-family:'DM Sans',sans-serif; line-height:1.4; max-height:80px;
    transition:border-color .2s;
  }
  .cp-textarea:focus{ border-color:#00d4ff; }
  .cp-textarea::placeholder{ color:#5a6478; }
  .cp-send{
    align-self:flex-end; width:36px; height:36px; border-radius:10px; border:none;
    background:linear-gradient(135deg,#00d4ff,#7b5cf0); color:#000; font-size:14px;
    cursor:pointer; display:grid; place-items:center; transition:opacity .2s; flex-shrink:0;
  }
  .cp-send:hover{ opacity:.85; }
  .cp-fab{
    width:48px; height:48px; border-radius:14px; border:none;
    background:linear-gradient(135deg,#00d4ff,#7b5cf0); color:#000; font-size:20px;
    cursor:pointer; display:grid; place-items:center;
    box-shadow:0 8px 24px rgba(0,212,255,.3); transition:transform .2s;
    position:relative;
  }
  .cp-fab:hover{ transform:scale(1.08); }
  .cp-badge{
    position:absolute; top:-4px; right:-4px; background:#ff4466; color:#fff;
    border-radius:99px; min-width:18px; height:18px; font-size:10px; font-weight:700;
    display:none; align-items:center; justify-content:center; padding:0 4px;
  }
  .cp-badge.visible{ display:flex; }
  .cp-empty{ text-align:center; padding:32px 16px; color:#5a6478; font-size:13px; }
</style>
<div class="cp-wrap" id="cp-wrap">
  <div class="cp-panel" id="cp-panel">
    <div class="cp-head">
      <div>
        <div class="cp-head-title">💬 Live Chat</div>
        <div class="cp-head-sub" id="cp-member-count">0 participants</div>
      </div>
      <button class="cp-close" onclick="this.closest('.cp-wrap').querySelector('#cp-panel').classList.remove('open')">✕</button>
    </div>
    <div class="cp-tabs">
      <button class="cp-tab active" id="tab-chat" onclick="_cpTab('chat')">CHAT</button>
      <button class="cp-tab" id="tab-qa" onclick="_cpTab('qa')">Q&amp;A <span id="qa-count"></span></button>
    </div>
    <div class="cp-messages" id="cp-messages"></div>
    <div class="cp-quick-reacts" id="cp-quick-reacts"></div>
    <div class="cp-input-row">
      <div class="cp-input-wrap">
        <div class="cp-type-row" id="cp-type-row">
          <button class="cp-type-btn active" id="type-chat" onclick="_cpMsgType('chat')">💬 Chat</button>
          <button class="cp-type-btn" id="type-question" onclick="_cpMsgType('question')">❓ Question</button>
        </div>
        <textarea class="cp-textarea" id="cp-textarea" rows="2" placeholder="Type a message…" onkeydown="_cpKeydown(event)"></textarea>
      </div>
      <button class="cp-send" onclick="_cpSend()">➤</button>
    </div>
  </div>
  <button class="cp-fab" id="cp-fab" onclick="_cpToggle()">
    💬
    <div class="cp-badge" id="cp-badge"></div>
  </button>
</div>`;
    this.el       = el;
    this._panel   = () => el.querySelector('#cp-panel');
    this._msgList = () => el.querySelector('#cp-messages');
    this._msgType = 'chat';
    this._tab     = 'chat';

    // Quick reactions bar
    const qrWrap = el.querySelector('#cp-quick-reacts');
    QUICK_REACTIONS.forEach(emoji => {
      const btn = document.createElement('button');
      btn.className = 'cp-qr-btn';
      btn.textContent = emoji;
      btn.title = 'React with ' + emoji;
      btn.onclick = () => this._broadcastReaction(emoji);
      qrWrap.appendChild(btn);
    });

    // Expose globals the inline handlers need (scoped to this instance)
    window._cpTab      = (t)  => this._switchTab(t);
    window._cpMsgType  = (t)  => this._setMsgType(t);
    window._cpSend     = ()   => this._send();
    window._cpKeydown  = (e)  => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this._send(); } };
    window._cpToggle   = ()   => this.toggle();
  }

  // ── Wire WebSocket ──────────────────────────────────────────────────────────
  _wire() {
    if (!this.ws) return;
    this.ws.addEventListener('message', ({ data }) => {
      const msg = JSON.parse(data);
      switch (msg.type) {
        case 'chat_message':  this._addMessage(msg.msg);           break;
        case 'chat_history':  this._loadHistory(msg.messages);     break;
        case 'chat_answered': this._markAnswered(msg.msgId);       break;
        case 'chat_reaction': this._updateReaction(msg);           break;
        case 'device_list':   this._updateCount(msg.devices);      break;
      }
    });
  }

  // ── Messages ────────────────────────────────────────────────────────────────
  _addMessage(msg) {
    this.messages.push(msg);
    if (!this.open_ || this._tab !== (msg.type === 'question' ? 'qa' : 'chat')) {
      this.unread++;
      this._updateBadge();
    }
    this._renderMessage(msg);
    this._scroll();

    // Update Q&A tab count
    const qCount = this.messages.filter(m => m.type === 'question' && !m.answered).length;
    this.el.querySelector('#qa-count').textContent = qCount > 0 ? `(${qCount})` : '';
  }

  _loadHistory(messages) {
    this.messages = messages;
    this._renderAll();
  }

  _renderAll() {
    const list = this._msgList();
    list.innerHTML = '';
    const tab = this._tab;
    const visible = this.messages.filter(m =>
      tab === 'chat' ? m.type !== 'question' : m.type === 'question'
    );
    if (!visible.length) {
      list.innerHTML = `<div class="cp-empty">${tab === 'qa' ? 'No questions yet' : 'No messages yet'}</div>`;
      return;
    }
    visible.forEach(m => this._renderMessage(m, false));
    this._scroll();
  }

  _renderMessage(msg, append = true) {
    // Filter by current tab
    const inTab = this._tab === 'qa' ? msg.type === 'question' : msg.type !== 'question';
    if (!inTab) return;

    const list    = this._msgList();
    const isMine  = msg.userId === this.userId;
    const isHost  = this.isSender;
    const time    = new Date(msg.ts).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });

    const el = document.createElement('div');
    el.className = `cp-msg${isMine ? ' mine' : ''}`;
    el.id        = `msg-${msg.id}`;

    const answered = msg.answered ? '<span class="cp-answered-badge">✓ Answered</span>' : '';
    const answerBtn = (isHost && msg.type === 'question' && !msg.answered)
      ? `<button class="cp-answer-btn" onclick="_cpMarkAnswered('${msg.id}')">Mark answered</button>` : '';

    el.innerHTML = `
      ${!isMine ? `<div class="cp-msg-name">${msg.userName}</div>` : ''}
      <div class="cp-bubble${msg.type === 'question' ? ' question' : ''}${msg.type === 'system' ? ' system' : ''}${msg.answered ? ' answered' : ''}">
        ${msg.text}
      </div>
      <div class="cp-msg-foot">
        <span class="cp-ts">${time}</span>
        <div class="cp-react-row" id="reacts-${msg.id}"></div>
        ${answered}${answerBtn}
      </div>`;

    list.querySelector('.cp-empty')?.remove();
    if (append) list.appendChild(el);
    else list.insertBefore(el, list.firstChild);

    window._cpMarkAnswered = (id) => {
      this.ws?.send(JSON.stringify({ type:'chat_answer', payload:{ msgId: id } }));
    };
  }

  _markAnswered(msgId) {
    const el = document.getElementById(`msg-${msgId}`);
    if (el) {
      el.querySelector('.cp-bubble')?.classList.add('answered');
      el.querySelector('.cp-answer-btn')?.remove();
      const foot = el.querySelector('.cp-msg-foot');
      if (foot && !foot.querySelector('.cp-answered-badge')) {
        const badge = document.createElement('span');
        badge.className = 'cp-answered-badge';
        badge.textContent = '✓ Answered';
        foot.appendChild(badge);
      }
    }
    const msg = this.messages.find(m => m.id === msgId);
    if (msg) msg.answered = true;
    const qCount = this.messages.filter(m => m.type === 'question' && !m.answered).length;
    this.el.querySelector('#qa-count').textContent = qCount > 0 ? `(${qCount})` : '';
  }

  _updateReaction({ msgId, emoji, count }) {
    const reactRow = document.getElementById(`reacts-${msgId}`);
    if (!reactRow) return;
    let chip = reactRow.querySelector(`[data-emoji="${emoji}"]`);
    if (!chip) {
      chip = document.createElement('div');
      chip.className = 'cp-react-chip';
      chip.dataset.emoji = emoji;
      chip.onclick = () => this.ws?.send(JSON.stringify({ type:'chat_react', payload:{ msgId, emoji } }));
      reactRow.appendChild(chip);
    }
    chip.innerHTML = `${emoji} <span class="cp-react-count">${count}</span>`;
  }

  _updateCount(devices) {
    const count = (devices || []).filter(d => d.role !== 'idle').length;
    this.el.querySelector('#cp-member-count').textContent = `${count} participant${count !== 1 ? 's' : ''}`;
  }

  // ── Input ───────────────────────────────────────────────────────────────────
  _send() {
    const ta   = this.el.querySelector('#cp-textarea');
    const text = ta.value.trim();
    if (!text) return;
    this.ws?.send(JSON.stringify({ type:'chat_message', payload:{ text, msgType: this._msgType } }));
    ta.value = '';
    ta.style.height = '';
  }

  _setMsgType(type) {
    this._msgType = type;
    this.el.querySelector('#type-chat').classList.toggle('active', type === 'chat');
    this.el.querySelector('#type-question').classList.toggle('active', type === 'question');
  }

  _switchTab(tab) {
    this._tab = tab;
    this.el.querySelector('#tab-chat').classList.toggle('active', tab === 'chat');
    this.el.querySelector('#tab-qa').classList.toggle('active', tab === 'qa');
    this._renderAll();
    if (tab === 'chat') this.unread = 0;
    this._updateBadge();
  }

  _broadcastReaction(emoji) {
    // Send as a system chat message with reaction
    this.ws?.send(JSON.stringify({ type:'chat_message', payload:{ text:`reacted ${emoji}`, msgType:'system' } }));
  }

  // ── Panel controls ──────────────────────────────────────────────────────────
  toggle()  { this.open_ ? this.close() : this.open(); }
  open()    { this.open_ = true; this._panel().classList.add('open'); this.unread = 0; this._updateBadge(); this._renderAll(); this.ws?.send(JSON.stringify({ type:'chat_history', payload:{} })); }
  close()   { this.open_ = false; this._panel().classList.remove('open'); }

  _scroll() {
    const list = this._msgList();
    list.scrollTop = list.scrollHeight;
  }

  _updateBadge() {
    const badge = this.el.querySelector('#cp-badge');
    if (this.unread > 0 && !this.open_) {
      badge.textContent = this.unread > 9 ? '9+' : this.unread;
      badge.classList.add('visible');
    } else {
      badge.classList.remove('visible');
    }
  }
}

export { ChatPanel };
