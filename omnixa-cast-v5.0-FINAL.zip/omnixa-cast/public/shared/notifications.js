/**
 * OMNIXA CAST — Push Notifications (Phase 6)
 * Uses Firebase Cloud Messaging for scheduled cast reminders
 * Also handles browser Notification API for immediate alerts
 */

const VAPID_KEY = 'YOUR_FCM_VAPID_KEY'; // Get from Firebase Console → Project Settings → Cloud Messaging

// ── Browser Push Permission ────────────────────────────────────────────────────
async function requestNotificationPermission() {
  if (!('Notification' in window)) return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  const result = await Notification.requestPermission();
  return result;
}

// ── FCM Token (for server-to-device push) ─────────────────────────────────────
async function getFCMToken(firebaseMessaging) {
  try {
    const token = await firebaseMessaging.getToken({ vapidKey: VAPID_KEY });
    return token;
  } catch (e) {
    console.warn('[FCM] Could not get token:', e.message);
    return null;
  }
}

// ── Register Service Worker for background push ────────────────────────────────
async function registerPushServiceWorker() {
  if (!('serviceWorker' in navigator)) return null;
  try {
    const reg = await navigator.serviceWorker.register('/sw-push.js');
    console.log('[Push] Service worker registered:', reg.scope);
    return reg;
  } catch (e) {
    console.warn('[Push] SW registration failed:', e.message);
    return null;
  }
}

// ── Send immediate browser notification (no server needed) ────────────────────
function showLocalNotification(title, body, opts = {}) {
  if (Notification.permission !== 'granted') return;
  const n = new Notification(title, {
    body,
    icon:  opts.icon  || '/public/assets/icons/icon-192.png',
    badge: opts.badge || '/public/assets/icons/badge-72.png',
    tag:   opts.tag   || 'omnixa-cast',
    data:  opts.data  || {},
    requireInteraction: opts.sticky || false,
  });
  n.onclick = () => {
    window.focus();
    if (opts.url) window.location.href = opts.url;
    n.close();
  };
  return n;
}

// ── Schedule a reminder notification ──────────────────────────────────────────
function scheduleReminder(cast, minutesBefore = 5) {
  const fireAt  = cast.scheduledAt - minutesBefore * 60 * 1000;
  const msUntil = fireAt - Date.now();
  if (msUntil <= 0) return null; // already past

  const timerId = setTimeout(() => {
    showLocalNotification(
      `⏰ Cast starting in ${minutesBefore} minutes`,
      `"${cast.title}" by ${cast.hostName}`,
      { url: window.location.origin + cast.joinUrl, sticky: true, tag: `cast-${cast.id}` }
    );
  }, msUntil);

  console.log(`[Push] Reminder set for "${cast.title}" in ${Math.round(msUntil/60000)}min`);
  return timerId;
}

// ── Cancel a scheduled reminder ────────────────────────────────────────────────
function cancelReminder(timerId) {
  if (timerId) clearTimeout(timerId);
}

// ── Save FCM token to server (for server-side push) ───────────────────────────
async function saveFCMToken(token, userId, serverUrl = '') {
  try {
    await fetch(`${serverUrl}/api/push-token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, userId }),
    });
  } catch {}
}

export {
  requestNotificationPermission,
  getFCMToken,
  registerPushServiceWorker,
  showLocalNotification,
  scheduleReminder,
  cancelReminder,
  saveFCMToken,
};
