/**
 * OMNIXA CAST — Stream Security & Encryption (Phase 4)
 *
 * WebRTC already uses DTLS-SRTP encryption for all media by default.
 * This module adds:
 *   1. Room password protection (SHA-256 challenge-response)
 *   2. Signaling message signing (HMAC-SHA256 with session key)
 *   3. ICE credential rotation hints
 */

// ── Room Password Protection ───────────────────────────────────────────────────
async function hashRoomPassword(password, salt) {
  const encoder = new TextEncoder();
  const data     = encoder.encode(password + salt);
  const hashBuf  = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

async function createRoomCredential(password, roomId) {
  const salt  = roomId + '-omnixa-cast-v1';
  const hash  = await hashRoomPassword(password, salt);
  return { hash, roomId, ts: Date.now() };
}

async function verifyRoomCredential(password, roomId, storedHash) {
  const salt      = roomId + '-omnixa-cast-v1';
  const candidate = await hashRoomPassword(password, salt);
  return candidate === storedHash;
}

// ── Session Key (for signing signaling messages) ───────────────────────────────
async function generateSessionKey() {
  const key = await crypto.subtle.generateKey(
    { name: 'HMAC', hash: 'SHA-256' },
    true,
    ['sign', 'verify']
  );
  const exported = await crypto.subtle.exportKey('raw', key);
  return btoa(String.fromCharCode(...new Uint8Array(exported)));
}

async function importSessionKey(b64Key) {
  const raw = Uint8Array.from(atob(b64Key), c => c.charCodeAt(0));
  return crypto.subtle.importKey('raw', raw, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
}

async function signMessage(message, b64Key) {
  const key      = await importSessionKey(b64Key);
  const data     = new TextEncoder().encode(JSON.stringify(message));
  const sigBuf   = await crypto.subtle.sign('HMAC', key, data);
  return btoa(String.fromCharCode(...new Uint8Array(sigBuf)));
}

async function verifyMessage(message, signature, b64Key) {
  try {
    const key    = await importSessionKey(b64Key);
    const data   = new TextEncoder().encode(JSON.stringify(message));
    const sigBuf = Uint8Array.from(atob(signature), c => c.charCodeAt(0));
    return crypto.subtle.verify('HMAC', key, sigBuf, data);
  } catch { return false; }
}

// ── DTLS-SRTP Status ───────────────────────────────────────────────────────────
// WebRTC mandates DTLS-SRTP — this just surfaces the status for display
async function getEncryptionStatus(pc) {
  if (!pc) return null;
  const stats = await pc.getStats();
  let dtlsState = null;
  stats.forEach(s => {
    if (s.type === 'transport') dtlsState = s.dtlsState;
  });
  return {
    dtls:    dtlsState === 'connected',
    srtp:    true, // always true when DTLS is connected in WebRTC
    status:  dtlsState === 'connected' ? '🔒 Encrypted (DTLS-SRTP)' : '⏳ Handshaking…',
  };
}

// ── Security Summary ───────────────────────────────────────────────────────────
function getSecuritySummary() {
  return {
    transport:   'DTLS 1.2+',
    media:       'SRTP (AES-128)',
    signaling:   'WebSocket (TLS in production)',
    auth:        'Firebase Authentication',
    recommended: [
      'Deploy server behind HTTPS (nginx + Let\'s Encrypt)',
      'Use WSS (WebSocket Secure) in production',
      'Set TURN_SECRET for timed credential rotation',
      'Enable Firebase App Check to prevent unauthorized API usage',
    ]
  };
}

export { hashRoomPassword, createRoomCredential, verifyRoomCredential, generateSessionKey, signMessage, verifyMessage, getEncryptionStatus, getSecuritySummary };
