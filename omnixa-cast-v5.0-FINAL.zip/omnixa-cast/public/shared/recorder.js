/**
 * OMNIXA CAST — Session Recorder (Phase 4)
 * Records the outgoing screen stream using MediaRecorder API
 * Saves to local download OR uploads to Firebase Storage
 *
 * Usage (sender page):
 *   import { Recorder } from '/shared/recorder.js';
 *   const rec = new Recorder(stream, { onProgress, onComplete });
 *   rec.start();  rec.stop();
 */

const MIME_TYPES = [
  'video/webm;codecs=vp9,opus',
  'video/webm;codecs=vp8,opus',
  'video/webm;codecs=h264',
  'video/webm',
  'video/mp4',
];

function getSupportedMime() {
  return MIME_TYPES.find(m => MediaRecorder.isTypeSupported(m)) || '';
}

class Recorder {
  constructor(stream, options = {}) {
    this.stream    = stream;
    this.options   = options;    // { onProgress, onComplete, onError, firebaseStorage, sessionId }
    this.recorder  = null;
    this.chunks    = [];
    this.startTime = null;
    this.mimeType  = getSupportedMime();
    this.recording = false;
    this._progressInterval = null;
  }

  start() {
    if (!this.stream || this.recording) return;
    this.chunks    = [];
    this.startTime = Date.now();
    this.recording = true;

    try {
      this.recorder = new MediaRecorder(this.stream, {
        mimeType: this.mimeType,
        videoBitsPerSecond: 2_500_000, // 2.5 Mbps for recording (lower than stream)
      });

      this.recorder.ondataavailable = (e) => {
        if (e.data?.size > 0) this.chunks.push(e.data);
      };

      this.recorder.onstop = () => this._finalize();
      this.recorder.onerror = (e) => {
        this.recording = false;
        this.options.onError?.(e.error?.message || 'Recording error');
      };

      // Collect chunks every 5 seconds (for progress + partial recovery)
      this.recorder.start(5000);

      // Progress reporting
      this._progressInterval = setInterval(() => {
        if (!this.recording) return;
        const elapsed   = Math.floor((Date.now() - this.startTime) / 1000);
        const totalSize = this.chunks.reduce((sum, c) => sum + c.size, 0);
        this.options.onProgress?.({ elapsed, bytes: totalSize });
      }, 1000);

      console.log(`[Recorder] Started — ${this.mimeType}`);
    } catch (e) {
      this.recording = false;
      this.options.onError?.(e.message);
    }
  }

  stop() {
    if (!this.recording || !this.recorder) return;
    clearInterval(this._progressInterval);
    this.recorder.stop();
    this.recording = false;
  }

  pause()  { if (this.recorder?.state === 'recording') this.recorder.pause(); }
  resume() { if (this.recorder?.state === 'paused')    this.recorder.resume(); }

  async _finalize() {
    const blob     = new Blob(this.chunks, { type: this.mimeType });
    const duration = Math.floor((Date.now() - this.startTime) / 1000);
    const ext      = this.mimeType.includes('mp4') ? 'mp4' : 'webm';
    const filename = `omnixa-cast-${new Date().toISOString().slice(0,19).replace(/:/g,'-')}.${ext}`;

    if (this.options.firebaseStorage && this.options.sessionId) {
      // Upload to Firebase Storage
      await this._uploadToFirebase(blob, filename);
    } else {
      // Local download
      this._downloadBlob(blob, filename);
    }

    this.options.onComplete?.({ blob, filename, duration, bytes: blob.size });
    console.log(`[Recorder] Saved — ${filename} (${(blob.size/1024/1024).toFixed(1)} MB, ${duration}s)`);
  }

  _downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a   = Object.assign(document.createElement('a'), { href: url, download: filename });
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  async _uploadToFirebase(blob, filename) {
    try {
      const { ref, uploadBytes, getDownloadURL } = await import('https://www.gstatic.com/firebasejs/10.8.0/firebase-storage.js');
      const storageRef = ref(this.options.firebaseStorage, `recordings/${this.options.sessionId}/${filename}`);
      const snap = await uploadBytes(storageRef, blob, { contentType: this.mimeType });
      const url  = await getDownloadURL(snap.ref);
      console.log(`[Recorder] Uploaded to Firebase Storage: ${url}`);
      return url;
    } catch (e) {
      console.error('[Recorder] Firebase upload failed, falling back to download:', e.message);
      this._downloadBlob(blob, filename);
    }
  }

  getElapsed() {
    if (!this.startTime) return 0;
    return Math.floor((Date.now() - this.startTime) / 1000);
  }

  static isSupported() {
    return typeof MediaRecorder !== 'undefined' && !!getSupportedMime();
  }
}

export { Recorder };
