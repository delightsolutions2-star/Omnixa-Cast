/**
 * OMNIXA CAST — Cast Annotations (Phase 5)
 * Sender draws on a transparent canvas overlay above the preview
 * Annotation strokes are broadcast to receivers via WebSocket data channel
 *
 * Tools: Pen, Highlighter, Arrow, Spotlight, Eraser, Clear
 */

class AnnotationCanvas {
  constructor(container, ws, senderId, opts = {}) {
    this.container = container;
    this.ws        = ws;
    this.senderId  = senderId;   // null on receiver side
    this.isSender  = !!senderId;
    this.opts = { color: opts.color || '#00d4ff', lineWidth: opts.lineWidth || 3, tool: opts.tool || 'pen' };

    this.canvas   = document.createElement('canvas');
    this.ctx      = this.canvas.getContext('2d');
    this.drawing  = false;
    this.lastX    = 0;
    this.lastY    = 0;
    this.strokes  = [];   // for undo
    this.spotlightActive = false;

    this._setup();
  }

  _setup() {
    Object.assign(this.canvas.style, {
      position: 'absolute', inset: '0', width: '100%', height: '100%',
      pointerEvents: this.isSender ? 'auto' : 'none',
      zIndex: '20', cursor: 'crosshair',
    });

    this._resize();
    this.container.style.position = 'relative';
    this.container.appendChild(this.canvas);

    if (this.isSender) {
      this.canvas.addEventListener('mousedown',  e => this._startDraw(e));
      this.canvas.addEventListener('mousemove',  e => this._draw(e));
      this.canvas.addEventListener('mouseup',    e => this._endDraw(e));
      this.canvas.addEventListener('mouseleave', e => this._endDraw(e));
      // Touch support
      this.canvas.addEventListener('touchstart', e => this._startDraw(e.touches[0]), { passive: true });
      this.canvas.addEventListener('touchmove',  e => { e.preventDefault(); this._draw(e.touches[0]); }, { passive: false });
      this.canvas.addEventListener('touchend',   e => this._endDraw(e));
    }

    window.addEventListener('resize', () => this._resize());
  }

  _resize() {
    const rect = this.container.getBoundingClientRect();
    this.canvas.width  = rect.width  || this.container.offsetWidth;
    this.canvas.height = rect.height || this.container.offsetHeight;
    this._redraw();
  }

  _coords(e) {
    const rect = this.canvas.getBoundingClientRect();
    const sx   = this.canvas.width  / rect.width;
    const sy   = this.canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * sx,
      y: (e.clientY - rect.top)  * sy,
      nx: (e.clientX - rect.left) / rect.width,   // normalized 0–1
      ny: (e.clientY - rect.top)  / rect.height,
    };
  }

  _startDraw(e) {
    this.drawing = true;
    const { x, y, nx, ny } = this._coords(e);
    this.lastX = x; this.lastY = y;
    this.currentStroke = { tool: this.opts.tool, color: this.opts.color, lineWidth: this.opts.lineWidth, points: [{ x, y }] };

    if (this.opts.tool === 'spotlight') {
      this._broadcast({ type:'annotation_spotlight', x:nx, y:ny, active:true });
    }
  }

  _draw(e) {
    if (!this.drawing) return;
    const { x, y, nx, ny } = this._coords(e);

    if (this.opts.tool === 'eraser') {
      this.ctx.clearRect(x - 15, y - 15, 30, 30);
    } else if (this.opts.tool === 'spotlight') {
      this._broadcast({ type:'annotation_spotlight', x:nx, y:ny, active:true });
      this.lastX = x; this.lastY = y;
      return;
    } else {
      this._drawSegment(this.ctx, this.lastX, this.lastY, x, y, this.opts);
    }

    if (this.currentStroke) this.currentStroke.points.push({ x, y });

    // Broadcast stroke segment
    this._broadcast({
      type: 'annotation_segment',
      tool: this.opts.tool,
      color: this.opts.color,
      lineWidth: this.opts.lineWidth,
      from: { x: this.lastX / this.canvas.width, y: this.lastY / this.canvas.height },
      to:   { x: x / this.canvas.width,          y: y / this.canvas.height },
    });

    this.lastX = x; this.lastY = y;
  }

  _endDraw() {
    if (!this.drawing) return;
    this.drawing = false;
    if (this.currentStroke && this.currentStroke.points.length > 1) {
      this.strokes.push(this.currentStroke);
    }
    this.currentStroke = null;
    if (this.opts.tool === 'spotlight') {
      this._broadcast({ type:'annotation_spotlight', active:false });
    }
  }

  _drawSegment(ctx, x1, y1, x2, y2, opts) {
    ctx.save();
    ctx.strokeStyle = opts.color;
    ctx.lineWidth   = opts.tool === 'highlighter' ? opts.lineWidth * 6 : opts.lineWidth;
    ctx.globalAlpha = opts.tool === 'highlighter' ? 0.35 : 1;
    ctx.lineCap     = 'round';
    ctx.lineJoin    = 'round';
    ctx.shadowColor = opts.tool === 'pen' ? opts.color : 'transparent';
    ctx.shadowBlur  = opts.tool === 'pen' ? 4 : 0;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
  }

  // Receive a segment from the sender (receiver side)
  receiveSegment(msg) {
    const w = this.canvas.width, h = this.canvas.height;
    const x1 = msg.from.x * w, y1 = msg.from.y * h;
    const x2 = msg.to.x   * w, y2 = msg.to.y   * h;
    this._drawSegment(this.ctx, x1, y1, x2, y2, { color: msg.color, lineWidth: msg.lineWidth, tool: msg.tool });
  }

  receiveSpotlight(msg) {
    if (msg.active) {
      this._drawSpotlight(msg.x * this.canvas.width, msg.y * this.canvas.height);
    } else {
      this._clearSpotlight();
    }
  }

  _drawSpotlight(x, y) {
    this.spotlightActive = true;
    // Clear previous spotlight layer — use composite trick
    this.ctx.save();
    // Re-draw strokes first then overlay spotlight
    this._redraw();
    this.ctx.fillStyle = 'rgba(0,0,0,0.55)';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.save();
    this.ctx.globalCompositeOperation = 'destination-out';
    const grad = this.ctx.createRadialGradient(x, y, 0, x, y, 120);
    grad.addColorStop(0, 'rgba(0,0,0,1)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    this.ctx.fillStyle = grad;
    this.ctx.beginPath();
    this.ctx.arc(x, y, 120, 0, Math.PI * 2);
    this.ctx.fill();
    this.ctx.restore();
    this.ctx.restore();
  }

  _clearSpotlight() {
    this.spotlightActive = false;
    this._redraw();
  }

  _redraw() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    // Replay all strokes
    this.strokes.forEach(s => {
      for (let i = 1; i < s.points.length; i++) {
        this._drawSegment(this.ctx, s.points[i-1].x, s.points[i-1].y, s.points[i].x, s.points[i].y, s);
      }
    });
  }

  clear() {
    this.strokes = [];
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this._broadcast({ type:'annotation_clear' });
  }

  undo() {
    if (this.strokes.length) {
      this.strokes.pop();
      this._redraw();
      this._broadcast({ type:'annotation_undo' });
    }
  }

  setTool(tool)       { this.opts.tool      = tool; }
  setColor(color)     { this.opts.color     = color; }
  setLineWidth(width) { this.opts.lineWidth = width; }

  _broadcast(data) {
    if (!this.ws || !this.isSender) return;
    try { this.ws.send(JSON.stringify(data)); } catch {}
  }

  destroy() {
    this.canvas.remove();
  }
}

export { AnnotationCanvas };
