/**
 * OMNIXA CAST — Firebase Initializer (Client-side)
 * Drop your Firebase config below — same config works on all client pages
 */

// ⚙️  REPLACE WITH YOUR FIREBASE PROJECT CONFIG
const FIREBASE_CONFIG = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID"
};

// Returns a ready Firebase instance (works as ES module via CDN)
// Each client page imports this via <script type="module">
export { FIREBASE_CONFIG };
