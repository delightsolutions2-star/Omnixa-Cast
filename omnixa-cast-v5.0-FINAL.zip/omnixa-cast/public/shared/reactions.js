/**
 * OMNIXA CAST — Viewer Reactions (Phase 6)
 * Emoji reactions from receivers float up and are visible on the sender's screen
 * Receivers tap emoji → sent via WebSocket → rendered as floating bubbles on all screens
 */

const REACTION_EMOJIS = ['👍','❤️','🔥','😮','😂','👏','🎉','💯'];
const REACTION_COLORS = {
  '👍':'#00d4ff', '❤️':'#ff4466', '🔥':'#f59e0b', '😮':'#7b5cf0',
  '😂':'#00e5a0', '👏':'#f59e0b', '🎉':'#7b5cf0', '💯':'#00d4ff'
};

class ReactionOverlay {
  constructor(ws, opts = {}) {
    this.ws         = ws;
    this.isSender   = opts.isSender || false;
    this.container  = opts.container || document.body;
    this._build();
    this._wire();
  }

  _build() {
    // Floating container for animated bubbles
    this.overlay = document.createElement('div');
    Object.assign(this.overlay.style, {
      position: 'fixed', bottom: '80px', left: '50%', transform: 'translateX(-50%)',
      zIndex: '300', pointerEvents: 'none', width: '200px', height: '400px',
    });
    document.body.appendChild(this.overlay);

    // Reaction bar (receiver only)
    if (!this.isSender) {
      this.bar = document.createElement('div');
      this.bar.style.cssText = `
        position:fixed; bottom:16px; left:50%; transform:translateX(-50%);
        z-index:300; display:flex; gap:8px; padding:10px 16px;
        background:rgba(5,7,9,.85); backdrop-filter:blur(12px);
        border:1px solid rgba(255,255,255,.1); border-radius:999px;
        box-shadow:0 8px 32px rgba(0,0,0,.5);
      `;
      REACTION_EMOJIS.forEach(emoji => {
        const btn = document.createElement('button');
        btn.style.cssText = `
          width:38px; height:38px; border-radius:50%; border:none;
          background:rgba(255,255,255,.06); cursor:pointer; font-size:20px;
          transition:transform .15s,background .2s; display:grid; place-items:center;
        `;
        btn.textContent = emoji;
        btn.title = emoji;
        btn.addEventListener('click', () => this._send(emoji));
        btn.addEventListener('mouseenter', () => { btn.style.transform='scale(1.25)'; btn.style.background='rgba(255,255,255,.12)'; });
        btn.addEventListener('mouseleave', () => { btn.style.transform='scale(1)'; btn.style.background='rgba(255,255,255,.06)'; });
        this.bar.appendChild(btn);
      });
      document.body.appendChild(this.bar);
    }
  }

  _wire() {
    if (!this.ws) return;
    this.ws.addEventListener('message', ({ data }) => {
      const msg = JSON.parse(data);
      if (msg.type === 'viewer_reaction') this._animate(msg.emoji, msg.userName);
    });
  }

  _send(emoji) {
    if (!this.ws) return;
    this.ws.send(JSON.stringify({ type:'viewer_reaction', payload:{ emoji } }));
    // Also animate locally (immediate feedback)
    this._animate(emoji, 'You');
  }

  _animate(emoji, userName = '') {
    const bubble = document.createElement('div');
    const startX = Math.random() * 120 - 60; // -60 to +60px
    const color  = REACTION_COLORS[emoji] || '#fff';

    Object.assign(bubble.style, {
      position:   'absolute',
      bottom:     '0',
      left:       `${50 + startX}px`,
      fontSize:   `${28 + Math.random() * 16}px`,
      lineHeight: '1',
      userSelect: 'none',
      pointerEvents: 'none',
      animation:  `reactionFloat ${1.8 + Math.random()}s ease-out forwards`,
      filter:     `drop-shadow(0 0 8px ${color})`,
    });
    bubble.textContent = emoji;
    this.overlay.appendChild(bubble);

    // Inject keyframe if needed
    if (!document.getElementById('reaction-style')) {
      const style = document.createElement('style');
      style.id = 'reaction-style';
      style.textContent = `
        @keyframes reactionFloat {
          0%   { transform:translateY(0) scale(1); opacity:1; }
          70%  { opacity:1; }
          100% { transform:translateY(-320px) scale(0.6) rotate(${(Math.random()-0.5)*20}deg); opacity:0; }
        }
      `;
      document.head.appendChild(style);
    }

    // Show sender name briefly
    if (userName && userName !== 'You') {
      const label = document.createElement('div');
      Object.assign(label.style, {
        position:'absolute', bottom:'0', left:`${50+startX-20}px`,
        fontSize:'10px', color:'rgba(255,255,255,.6)', whiteSpace:'nowrap',
        animation:`reactionFloat ${1.8}s ease-out forwards`, fontFamily:'DM Sans,sans-serif',
      });
      label.textContent = userName;
      this.overlay.appendChild(label);
      setTimeout(() => label.remove(), 2000);
    }

    setTimeout(() => bubble.remove(), 2200);
  }

  show() { this.bar?.style && (this.bar.style.display = 'flex'); }
  hide() { this.bar?.style && (this.bar.style.display = 'none'); }
  destroy() { this.overlay.remove(); this.bar?.remove(); }
}

export { ReactionOverlay, REACTION_EMOJIS };
