/**
 * OMNIXA CAST — Shared WebRTC Helper (Phase 4)
 * Auto-fetches ICE config from server (supports TURN for cloud casting)
 * Used by sender, receiver, and TV pages
 */

let _iceConfig = null;
let _castingMode = 'auto';

// ── Fetch ICE config from server (call once at startup) ───────────────────────
async function fetchICEConfig() {
  try {
    const [iceRes, modeRes] = await Promise.all([
      fetch('/api/ice-config'),
      fetch('/api/casting-mode'),
    ]);
    _iceConfig    = await iceRes.json();
    const modeData = await modeRes.json();
    _castingMode  = modeData.mode || 'auto';
    console.log(`[WebRTC] Mode: ${_castingMode}, ICE servers: ${_iceConfig.iceServers?.length}`);
    return _iceConfig;
  } catch (e) {
    console.warn('[WebRTC] Could not fetch ICE config, using STUN only:', e.message);
    _iceConfig = {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
      ]
    };
    return _iceConfig;
  }
}

// ── Create a peer connection using the fetched config ─────────────────────────
function createPeerConnection() {
  if (!_iceConfig) {
    console.warn('[WebRTC] ICE config not loaded yet — call fetchICEConfig() first');
  }
  return new RTCPeerConnection(_iceConfig || { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
}

// ── Apply 4Mbps bitrate cap to sender ─────────────────────────────────────────
async function applyBitrateCap(pc, maxKbps = 4000) {
  for (const sender of pc.getSenders()) {
    if (sender.track?.kind === 'video') {
      const params = sender.getParameters();
      if (!params.encodings?.length) params.encodings = [{}];
      params.encodings[0].maxBitrate = maxKbps * 1000;
      params.encodings[0].networkPriority = 'high';
      try { await sender.setParameters(params); } catch {}
    }
  }
}

// ── Get current connection stats ───────────────────────────────────────────────
async function getConnectionStats(pc) {
  const stats = await pc.getStats();
  const result = { bytesSent: 0, bytesReceived: 0, roundTripTime: null, candidateType: null };
  stats.forEach(s => {
    if (s.type === 'outbound-rtp' && s.kind === 'video')  result.bytesSent     += s.bytesSent || 0;
    if (s.type === 'inbound-rtp'  && s.kind === 'video')  result.bytesReceived += s.bytesReceived || 0;
    if (s.type === 'remote-inbound-rtp') result.roundTripTime = s.roundTripTime;
    if (s.type === 'candidate-pair' && s.state === 'succeeded') {
      result.candidateType = s.remoteCandidateId ? 'relay' : 'direct';
    }
  });
  return result;
}

// ── Detect if we're on the same LAN as the server ─────────────────────────────
function isLikelyLocalNetwork() {
  const href = location.href;
  return href.includes('192.168.') || href.includes('10.') ||
         href.includes('172.') || href.includes('localhost');
}

function getCastingMode()  { return _castingMode; }
function getICEConfig()    { return _iceConfig; }

export { fetchICEConfig, createPeerConnection, applyBitrateCap, getConnectionStats, isLikelyLocalNetwork, getCastingMode };
