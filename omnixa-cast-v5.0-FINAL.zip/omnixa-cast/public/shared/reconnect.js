/**
 * OMNIXA CAST — Auto-Reconnection Manager (Phase 5)
 *
 * Handles WebSocket + WebRTC peer reconnection with:
 *  - Exponential backoff (1s → 2s → 4s → 8s → 30s max)
 *  - Jitter to avoid thundering herd on server restart
 *  - Status callbacks for UI updates
 *  - Graceful teardown
 */

class ReconnectManager {
  constructor(options = {}) {
    this.options = {
      minDelay:    options.minDelay    || 1000,
      maxDelay:    options.maxDelay    || 30000,
      factor:      options.factor      || 2,
      jitter:      options.jitter      ?? true,
      maxAttempts: options.maxAttempts || 0,       // 0 = unlimited
      onAttempt:   options.onAttempt   || (() => {}),
      onConnect:   options.onConnect   || (() => {}),
      onGiveUp:    options.onGiveUp    || (() => {}),
    };
    this._attempts  = 0;
    this._delay     = this.options.minDelay;
    this._timer     = null;
    this._stopped   = false;
  }

  // Schedule next reconnect attempt
  schedule(connectFn) {
    if (this._stopped) return;
    if (this.options.maxAttempts && this._attempts >= this.options.maxAttempts) {
      this.options.onGiveUp(this._attempts);
      return;
    }

    const jitter = this.options.jitter ? Math.random() * 0.3 * this._delay : 0;
    const delay  = Math.min(this._delay + jitter, this.options.maxDelay);

    console.log(`[Reconnect] Attempt ${this._attempts + 1} in ${Math.round(delay)}ms…`);
    this.options.onAttempt(this._attempts + 1, Math.round(delay));

    this._timer = setTimeout(() => {
      this._attempts++;
      connectFn();
    }, delay);

    // Exponential backoff for next round
    this._delay = Math.min(this._delay * this.options.factor, this.options.maxDelay);
  }

  // Call when connection succeeds
  onSuccess() {
    this._attempts = 0;
    this._delay    = this.options.minDelay;
    clearTimeout(this._timer);
    this.options.onConnect();
  }

  // Permanently stop retrying
  stop() {
    this._stopped = true;
    clearTimeout(this._timer);
  }

  reset() {
    this._stopped  = false;
    this._attempts = 0;
    this._delay    = this.options.minDelay;
    clearTimeout(this._timer);
  }

  get attempts() { return this._attempts; }
}

/**
 * WebRTC peer reconnection helper
 * Renegotiates a failed peer connection without dropping all receivers
 */
class PeerReconnectManager {
  constructor(ws, peersMap, streamGetter) {
    this.ws          = ws;
    this.peers       = peersMap;
    this.getStream   = streamGetter;
    this._watchers   = {};
  }

  // Watch a peer connection for failure and auto-reconnect
  watch(receiverId) {
    if (this._watchers[receiverId]) return;
    const entry = this.peers[receiverId];
    if (!entry?.pc) return;

    let reattempts = 0;
    const check = async () => {
      const state = entry.pc?.connectionState;
      if (state === 'failed' || state === 'disconnected') {
        if (reattempts++ < 3) {
          console.log(`[PeerReconnect] Renegotiating with ${receiverId} (attempt ${reattempts})`);
          await this._renegotiate(receiverId);
        } else {
          console.log(`[PeerReconnect] Giving up on ${receiverId} after 3 attempts`);
          this.stopWatching(receiverId);
        }
      }
    };

    entry.pc.onconnectionstatechange = () => {
      if (['failed','disconnected'].includes(entry.pc.connectionState)) {
        setTimeout(check, 1500); // short delay before renegotiating
      }
    };

    this._watchers[receiverId] = true;
  }

  async _renegotiate(receiverId) {
    const entry  = this.peers[receiverId];
    const stream = this.getStream();
    if (!entry?.pc || !stream) return;

    try {
      const offer = await entry.pc.createOffer({ iceRestart: true }); // ICE restart = new credentials
      await entry.pc.setLocalDescription(offer);
      this.ws.send(JSON.stringify({
        type: 'offer',
        payload: { targetId: receiverId, sdp: entry.pc.localDescription }
      }));
    } catch (e) {
      console.error('[PeerReconnect] Renegotiation failed:', e.message);
    }
  }

  stopWatching(receiverId) {
    delete this._watchers[receiverId];
  }
}

export { ReconnectManager, PeerReconnectManager };
